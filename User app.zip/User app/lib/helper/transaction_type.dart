class TransactionType{
  static const String  sendMoney = 'send_money';
  static const String  addMoney = 'add_money';
  static const String  cashOut = 'cash_out';
  static const String  requestMoney= 'request_money';
  static const String  withdrawRequest = 'withdraw_request';
}