# Guide d'installation et d'utilisation

## Introduction

Ce package contient l'application Eocopay avec les nouvelles intégrations de passerelles de paiement CinetPay et SMobilPay. Ces intégrations permettent aux utilisateurs d'effectuer des paiements via ces deux services, que ce soit en ligne ou hors ligne.

## Installation

1. Décompressez l'archive ZIP dans un répertoire de votre choix
2. Ouvrez le projet dans votre environnement de développement Flutter
3. Exécutez la commande suivante pour installer les dépendances :
   ```
   flutter pub get
   ```
4. Configurez les clés API des passerelles de paiement dans le fichier `lib/features/payment/config/app_config.dart`

## Configuration des passerelles de paiement

### Prérequis

Pour utiliser les passerelles de paiement, vous devez disposer des éléments suivants :

#### Pour CinetPay :
- Une clé API CinetPay
- Un identifiant de site (Site ID)
- Une URL de notification

#### Pour SMobilPay :
- Un token d'accès public
- Une clé secrète d'accès
- Une URL de callback

### Configuration

1. Ouvrez le fichier `lib/features/payment/config/app_config.dart`
2. Remplacez les valeurs par défaut par vos propres informations d'identification

## Fonctionnalités principales

- **Interface de paiement unifiée** : Les utilisateurs peuvent choisir entre différentes méthodes de paiement, y compris CinetPay et SMobilPay
- **Support hors ligne** : Les transactions initiées hors ligne sont mises en file d'attente et synchronisées lorsque la connexion est rétablie
- **Module de test** : Un module de test est inclus pour vérifier le bon fonctionnement des passerelles de paiement

## Documentation détaillée

Pour une documentation plus détaillée sur l'intégration des passerelles de paiement, veuillez consulter le fichier `PAYMENT_INTEGRATION_DOCS.md` inclus dans ce package.

## Support

En cas de problème ou de question, veuillez contacter l'équipe de support à l'adresse support@eocopay.com.
