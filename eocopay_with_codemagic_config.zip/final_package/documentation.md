# Documentation du Module de Chat Hors Ligne

## Introduction

Ce document décrit l'implémentation du module de chat hors ligne avec support SMS et RCS intégré à l'application Six Cash. Ce module permet aux utilisateurs de communiquer même sans connexion internet, en utilisant les SMS comme solution de repli, et offre des fonctionnalités enrichies (comme les emojis) via RCS lorsque disponible.

## Architecture

Le module de chat est conçu selon une architecture modulaire qui s'intègre parfaitement avec l'application existante. Il comprend :

1. **Modèles de données** : Structures pour représenter les messages et les conversations
2. **Services** : Gestion du stockage local, SMS, RCS et synchronisation
3. **Contrôleurs** : Logique métier pour les écrans de chat
4. **Interfaces utilisateur** : Écrans et widgets pour interagir avec le chat

## Fonctionnalités principales

### Mode hors ligne
- Détection automatique de l'état de connectivité
- Basculement transparent entre les modes en ligne et hors ligne
- Indicateur visuel de l'état de connexion

### Support SMS
- Envoi et réception de SMS lorsque hors ligne
- Stockage local des messages SMS
- Synchronisation des messages SMS avec le serveur lors du retour en ligne

### Support RCS
- Envoi et réception de messages RCS enrichis
- Support des emojis et autres contenus enrichis
- Indicateurs de statut des messages (envoyé, livré, lu)

### Stockage local
- Persistance des conversations et messages
- Gestion efficace des données avec SharedPreferences et FlutterSecureStorage
- Limitation du nombre de messages stockés pour optimiser l'espace

### Synchronisation
- Synchronisation automatique lors du retour en ligne
- Gestion des conflits et des messages dupliqués
- Indicateur de dernière synchronisation

## Intégration avec l'application existante

Le module de chat s'intègre avec les fonctionnalités hors ligne existantes :
- Utilisation du même service de détection de connectivité
- Cohérence visuelle avec la bannière de mode hors ligne
- Accès facile depuis l'interface utilisateur principale

## Guide d'utilisation

### Accès au chat
1. Depuis l'écran d'accueil, appuyez sur le bouton "Messages"
2. La liste des conversations s'affiche, avec indication de l'état de connexion

### Envoi de messages
1. Sélectionnez une conversation ou créez-en une nouvelle
2. Tapez votre message dans le champ de texte
3. Appuyez sur le bouton d'envoi
4. Le message sera envoyé via internet, RCS ou SMS selon la disponibilité

### Utilisation des emojis
1. Appuyez sur l'icône emoji à côté du champ de texte
2. Sélectionnez un emoji dans le sélecteur
3. L'emoji sera envoyé ou ajouté à votre message

### Mode hors ligne
- Une bannière s'affiche en haut de l'écran lorsque vous êtes hors ligne
- Les messages sont envoyés par SMS et stockés localement
- Lors du retour en ligne, les messages sont automatiquement synchronisés

## Tests et dépannage

Un écran de test est disponible pour vérifier le bon fonctionnement du module :
1. Accédez à l'écran de test via le bouton "Tester le chat hors ligne"
2. Testez les différentes fonctionnalités : permissions SMS, envoi/réception, RCS, synchronisation
3. Les résultats des tests s'affichent directement sur l'écran

## Dépendances

Le module utilise les bibliothèques suivantes :
- `emoji_picker_flutter` : Pour le sélecteur d'emojis
- `flutter_sms` : Pour l'envoi de SMS
- `telephony` : Pour l'interception des SMS entrants
- `flutter_chat_bubble` : Pour l'affichage des bulles de chat
- `shared_preferences` et `flutter_secure_storage` : Pour le stockage local

## Limitations actuelles

- La réception de SMS nécessite que l'application soit en cours d'exécution
- Le support RCS est simulé et nécessiterait une intégration avec les API des opérateurs pour une implémentation complète
- Les fonctionnalités multimédia (images, vidéos) ne sont pas encore implémentées

## Évolutions futures

- Support des pièces jointes (images, vidéos, fichiers)
- Chiffrement de bout en bout des messages
- Notifications push pour les messages reçus en arrière-plan
- Intégration avec les contacts du téléphone
- Support des discussions de groupe
