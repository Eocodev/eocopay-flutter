# Guide d'intégration des passerelles de paiement CinetPay et SMobilPay

## Introduction

Ce guide explique comment utiliser les intégrations des passerelles de paiement CinetPay et SMobilPay dans l'application Eocopay. Ces intégrations permettent aux utilisateurs d'effectuer des paiements via différentes méthodes, en ligne et hors ligne.

## Configuration des passerelles dans le panneau d'administration

### Configuration de CinetPay
1. Accédez à https://eocopay.com/admin/payment/cinetpay
2. Activez la passerelle en basculant le commutateur sur "Enable"
3. Entrez votre API Key CinetPay (obtenue depuis votre compte CinetPay)
4. Entrez votre Site ID CinetPay
5. Configurez les devises supportées (par défaut: XOF,XAF,CDF,GNF)
6. Sélectionnez les canaux de paiement souhaités
7. Cliquez sur "Save" pour enregistrer la configuration

### Configuration de SMobilPay
1. Accédez à https://eocopay.com/admin/payment/smobilpay
2. Entrez votre clé publique SMobilPay
3. Entrez votre clé privée SMobilPay
4. Sélectionnez le mode (Test/Live)
5. Activez la passerelle en sélectionnant "Active"
6. Activez les services souhaités (achat de produits, paiement de factures, etc.)
7. Cliquez sur "Save Changes" pour enregistrer la configuration

## Utilisation dans l'application

Une fois les passerelles configurées dans le panneau d'administration, elles apparaîtront automatiquement dans l'application mobile comme options de paiement disponibles.

### Pour les développeurs

Le code d'intégration est organisé comme suit:
- `lib/features/payment/domain/models/` - Modèles de données pour les transactions
- `lib/features/payment/domain/services/` - Adaptateurs pour CinetPay et SMobilPay
- `lib/features/payment/screens/` - Écrans de paiement et de sélection de méthode
- `lib/features/payment/config/` - Configuration des passerelles

Pour ajouter de nouvelles fonctionnalités ou passerelles, suivez l'architecture existante et créez de nouveaux adaptateurs qui implémentent l'interface commune.

## Support hors ligne

Les deux intégrations supportent le mode hors ligne:
- Les transactions initiées hors ligne sont mises en file d'attente
- Elles sont traitées automatiquement lorsque la connexion est rétablie
- Les utilisateurs sont informés du statut de leurs transactions

## Dépannage

Si vous rencontrez des problèmes:
1. Vérifiez que les clés API sont correctement configurées
2. Assurez-vous que les passerelles sont activées
3. Vérifiez les journaux de l'application pour les messages d'erreur
4. Contactez le support technique si nécessaire

## Conclusion

Ces intégrations offrent une solution de paiement complète et flexible pour l'application Eocopay, permettant aux utilisateurs de choisir parmi différentes méthodes de paiement selon leurs préférences et leur situation.
