# Architecture d'intégration des passerelles de paiement

## 1. Vue d'ensemble

L'architecture proposée vise à intégrer deux passerelles de paiement (CinetPay et SMobilPay) dans l'application existante tout en maintenant une interface utilisateur cohérente et en permettant une extension future avec d'autres passerelles de paiement.

## 2. Structure de l'architecture

### 2.1 Architecture en couches

L'architecture suivra un modèle en couches pour séparer les préoccupations :

1. **Couche UI** : Interface utilisateur pour la sélection et l'interaction avec les méthodes de paiement
2. **Couche Service** : Logique métier et coordination des paiements
3. **Couche Adaptateur** : Adaptateurs spécifiques pour chaque passerelle de paiement
4. **Couche Infrastructure** : Implémentations concrètes des SDK et API

### 2.2 Diagramme de composants

```
+-------------------+
|    UI Layer       |
| (Payment Widgets) |
+--------+----------+
         |
+--------v----------+
|  Service Layer    |
| (Payment Service) |
+--------+----------+
         |
+--------v----------+
| Adapter Layer     |
| (Payment Adapters)|
+--------+----------+
         |
+--------v----------+
| Infrastructure    |
| (SDK/API Clients) |
+-------------------+
```

## 3. Composants principaux

### 3.1 Interface de paiement unifiée (PaymentService)

```dart
abstract class PaymentService {
  Future<bool> initializePayment();
  Future<PaymentResult> processPayment({
    required double amount,
    required String currency,
    required String transactionId,
    required String description,
    Map<String, dynamic>? metadata,
  });
  Future<PaymentStatus> checkPaymentStatus(String transactionId);
  List<PaymentMethod> getAvailablePaymentMethods();
}
```

### 3.2 Adaptateurs de passerelles de paiement

#### 3.2.1 CinetPayAdapter

```dart
class CinetPayAdapter implements PaymentService {
  final CinetPayConfig config;
  
  CinetPayAdapter(this.config);
  
  @override
  Future<bool> initializePayment() async {
    // Initialisation spécifique à CinetPay
    return true;
  }
  
  @override
  Future<PaymentResult> processPayment({
    required double amount,
    required String currency,
    required String transactionId,
    required String description,
    Map<String, dynamic>? metadata,
  }) async {
    // Implémentation spécifique à CinetPay
    // Utilisation du widget CinetPayCheckout
    return PaymentResult(...);
  }
  
  // Autres méthodes implémentées...
}
```

#### 3.2.2 SMobilPayAdapter

```dart
class SMobilPayAdapter implements PaymentService {
  final SMobilPayConfig config;
  
  SMobilPayAdapter(this.config);
  
  @override
  Future<bool> initializePayment() async {
    // Initialisation spécifique à SMobilPay
    // Authentification avec public access token et access secret
    return true;
  }
  
  @override
  Future<PaymentResult> processPayment({
    required double amount,
    required String currency,
    required String transactionId,
    required String description,
    Map<String, dynamic>? metadata,
  }) async {
    // Implémentation spécifique à SMobilPay
    // Appels API REST avec form data
    return PaymentResult(...);
  }
  
  // Autres méthodes implémentées...
}
```

### 3.3 Gestionnaire de paiement (PaymentManager)

```dart
class PaymentManager {
  final Map<String, PaymentService> _paymentServices;
  
  PaymentManager(this._paymentServices);
  
  List<PaymentMethod> getAllPaymentMethods() {
    List<PaymentMethod> methods = [];
    for (var service in _paymentServices.values) {
      methods.addAll(service.getAvailablePaymentMethods());
    }
    return methods;
  }
  
  Future<PaymentResult> processPayment({
    required String paymentMethodId,
    required double amount,
    required String currency,
    required String description,
  }) async {
    final String serviceKey = _getServiceKeyForMethod(paymentMethodId);
    final service = _paymentServices[serviceKey];
    
    if (service == null) {
      return PaymentResult.error("Méthode de paiement non prise en charge");
    }
    
    final transactionId = _generateTransactionId();
    
    return service.processPayment(
      amount: amount,
      currency: currency,
      transactionId: transactionId,
      description: description,
    );
  }
  
  // Méthodes utilitaires...
}
```

## 4. Intégration avec l'application existante

### 4.1 Modification du contrôleur AddMoneyController

```dart
class AddMoneyController extends GetxController implements GetxService {
  final AddMoneyRepo addMoneyRepo;
  final PaymentManager paymentManager;
  
  AddMoneyController({
    required this.addMoneyRepo,
    required this.paymentManager,
  });
  
  // Méthodes existantes...
  
  Future<void> addMoney(double amount) async {
    _isLoading = true;
    update();
    
    if (_paymentMethod == "cinetpay" || _paymentMethod == "smobilpay") {
      final result = await paymentManager.processPayment(
        paymentMethodId: _paymentMethod!,
        amount: amount,
        currency: "XOF", // À adapter selon les besoins
        description: "Ajout d'argent",
      );
      
      if (result.isSuccess) {
        // Traitement du succès
      } else {
        // Traitement de l'erreur
      }
    } else {
      // Utiliser le flux de paiement existant
      Response response = await addMoneyRepo.addMoneyApi(
        amount: amount, 
        paymentMethod: _paymentMethod!
      );
      // Traitement existant...
    }
    
    _isLoading = false;
    update();
  }
}
```

### 4.2 Modification du widget DigitalPaymentWidget

```dart
class DigitalPaymentWidget extends StatefulWidget {
  const DigitalPaymentWidget({super.key});

  @override
  State<DigitalPaymentWidget> createState() => _DigitalPaymentWidgetState();
}

class _DigitalPaymentWidgetState extends State<DigitalPaymentWidget> {
  AutoScrollController? scrollController;

  @override
  void initState() {
    scrollController = AutoScrollController(
      viewportBoundaryGetter: () => Rect.fromLTRB(0, 0, 0, MediaQuery.of(context).padding.bottom),
      axis: Axis.horizontal,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // Obtenir les méthodes de paiement existantes
    final List<DigitalPaymentMethod> existingPaymentList = 
        Get.find<SplashController>().configModel!.activePaymentMethodList ?? [];
    
    // Ajouter les nouvelles méthodes de paiement
    final List<DigitalPaymentMethod> paymentList = [
      ...existingPaymentList,
      DigitalPaymentMethod(
        gateway: "cinetpay",
        label: "CinetPay",
        gatewayImage: "cinetpay_logo.png",
      ),
      DigitalPaymentMethod(
        gateway: "smobilpay",
        label: "SMobilPay",
        gatewayImage: "smobilpay_logo.png",
      ),
    ];
    
    // Reste du code existant...
  }
}
```

## 5. Configuration et initialisation

### 5.1 Configuration des passerelles

```dart
// Dans le fichier de configuration ou d'initialisation
final cinetPayConfig = CinetPayConfig(
  apiKey: "YOUR_CINETPAY_API_KEY",
  siteId: YOUR_CINETPAY_SITE_ID,
  notifyUrl: "https://votre-domaine.com/notify/",
);

final sMobilPayConfig = SMobilPayConfig(
  publicAccessToken: "YOUR_SMOBILPAY_PUBLIC_TOKEN",
  accessSecret: "YOUR_SMOBILPAY_ACCESS_SECRET",
  environment: "production", // ou "test"
);

// Initialisation du gestionnaire de paiement
final paymentManager = PaymentManager({
  "cinetpay": CinetPayAdapter(cinetPayConfig),
  "smobilpay": SMobilPayAdapter(sMobilPayConfig),
});

// Enregistrement dans GetX
Get.put(paymentManager);
```

## 6. Gestion des erreurs et des exceptions

```dart
class PaymentException implements Exception {
  final String message;
  final String code;
  final dynamic details;
  
  PaymentException(this.message, {this.code = "", this.details});
  
  @override
  String toString() => "PaymentException: $message (Code: $code)";
}

// Utilisation dans les adaptateurs
try {
  // Code de paiement...
} catch (e) {
  throw PaymentException(
    "Échec du paiement",
    code: "PAYMENT_FAILED",
    details: e.toString(),
  );
}
```

## 7. Considérations de sécurité

1. **Stockage sécurisé des clés API** : Utilisation de flutter_secure_storage pour les clés sensibles
2. **Validation des entrées** : Validation des montants et autres paramètres avant de les envoyer aux API
3. **HTTPS** : S'assurer que toutes les communications utilisent HTTPS
4. **Gestion des tokens** : Stockage sécurisé et rotation des tokens d'authentification

## 8. Extensibilité

L'architecture proposée permet d'ajouter facilement de nouvelles passerelles de paiement en :
1. Créant un nouvel adaptateur qui implémente l'interface PaymentService
2. Ajoutant la configuration nécessaire
3. Enregistrant l'adaptateur dans le PaymentManager

Aucune modification des couches supérieures (UI, logique métier) n'est nécessaire.
