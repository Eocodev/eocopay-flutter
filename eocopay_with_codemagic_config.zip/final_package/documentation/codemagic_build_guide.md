# Guide d'utilisation de Codemagic pour compiler l'APK de test

Ce guide vous explique comment utiliser Codemagic pour compiler un APK de test de l'application Eocopay avec les intégrations de paiement CinetPay et SMobilPay.

## Étape 1 : Créer un compte Codemagic

1. Rendez-vous sur [https://codemagic.io/signup](https://codemagic.io/signup)
2. Inscrivez-vous avec votre compte GitHub, GitLab, Bitbucket ou une adresse e-mail
3. Suivez les instructions pour compléter votre inscription

## Étape 2 : Préparer le code source

1. Décompressez le fichier `final_package.zip` que je vous ai fourni
2. Assurez-vous que le fichier `codemagic.yaml` est présent à la racine du projet

## Étape 3 : Créer un nouveau projet sur Codemagic

1. Connectez-vous à votre compte Codemagic
2. Cliquez sur "Add application" dans le tableau de bord
3. Sélectionnez l'option "Add app from custom source"
4. Cliquez sur "Upload source code"
5. Compressez le dossier du projet en ZIP et téléchargez-le

## Étape 4 : Configurer le build

1. Une fois le code source téléchargé, Codemagic détectera automatiquement le fichier `codemagic.yaml`
2. Cliquez sur "Start new build" pour lancer la compilation
3. Sélectionnez le workflow "android-workflow" dans la liste déroulante
4. Cliquez sur "Start build"

## Étape 5 : Récupérer l'APK

1. Attendez que le build soit terminé (cela peut prendre quelques minutes)
2. Une fois le build réussi, cliquez sur l'onglet "Artifacts"
3. Téléchargez le fichier APK généré (`app-release.apk`)

## Étape 6 : Installer l'APK sur votre appareil Android

1. Transférez le fichier APK sur votre appareil Android
2. Sur votre appareil, accédez aux Paramètres > Sécurité
3. Activez "Sources inconnues" pour permettre l'installation d'applications en dehors du Play Store
4. Utilisez un gestionnaire de fichiers pour naviguer jusqu'à l'APK et tapez dessus pour l'installer

## Remarques importantes

- Assurez-vous que votre appareil Android a une version d'Android 5.0 (API 21) ou supérieure
- Pour tester les passerelles de paiement, vous devrez configurer les clés API dans l'application
- Si vous rencontrez des problèmes lors de la compilation, vérifiez les journaux de build sur Codemagic pour identifier les erreurs

## Support

Si vous avez des questions ou rencontrez des difficultés, n'hésitez pas à me contacter pour obtenir de l'aide supplémentaire.
