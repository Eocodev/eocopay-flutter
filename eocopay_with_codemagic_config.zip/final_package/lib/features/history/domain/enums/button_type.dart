enum ButtonType{
  all, sendMoney, cashIn, addMoney, revivedMoney, cashOut, withdraw, payment
}