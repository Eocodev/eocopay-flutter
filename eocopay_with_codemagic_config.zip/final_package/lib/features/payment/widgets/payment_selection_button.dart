import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/add_money/controllers/add_money_controller.dart';
import 'package:six_cash/features/payment/screens/unified_payment_screen.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/common/widgets/custom_button.dart';

class PaymentSelectionButton extends StatelessWidget {
  final double amount;
  final Function(bool success) onPaymentComplete;
  
  const PaymentSelectionButton({
    Key? key,
    required this.amount,
    required this.onPaymentComplete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AddMoneyController>(
      builder: (addMoneyController) {
        return CustomButton(
          buttonText: 'Choisir un moyen de paiement',
          onPressed: () async {
            // Réinitialiser le résultat du paiement précédent
            addMoneyController.clearPaymentResult();
            
            // Naviguer vers l'écran de sélection de paiement unifié
            final result = await Get.to<bool>(
              () => UnifiedPaymentScreen(
                amount: amount,
                selectedPaymentMethod: addMoneyController.paymentMethod,
              ),
            );
            
            // Traiter le résultat du paiement
            if (result == true) {
              onPaymentComplete(true);
            }
          },
          icon: Icons.payment,
        );
      },
    );
  }
}
