import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/payment/domain/services/payment_dependency_injection.dart';
import 'package:six_cash/util/app_constants.dart';

class AppConfig {
  static void initializePaymentGateways() {
    // Initialisation des constantes pour les passerelles de paiement
    AppConstants.CINETPAY_API_KEY = 'VOTRE_CLE_API_CINETPAY';
    AppConstants.CINETPAY_SITE_ID = 12345; // Remplacer par votre Site ID
    AppConstants.CINETPAY_NOTIFY_URL = 'https://votre-domaine.com/notify/cinetpay';
    
    AppConstants.SMOBILPAY_PUBLIC_TOKEN = 'VOTRE_TOKEN_PUBLIC_SMOBILPAY';
    AppConstants.SMOBILPAY_ACCESS_SECRET = 'VOTRE_SECRET_SMOBILPAY';
    AppConstants.SMOBILPAY_ENVIRONMENT = 'test'; // 'test' ou 'production'
    AppConstants.SMOBILPAY_CALLBACK_URL = 'https://votre-domaine.com/notify/smobilpay';
    
    // Initialisation des services de paiement
    PaymentDependencyInjection.init();
  }
}
