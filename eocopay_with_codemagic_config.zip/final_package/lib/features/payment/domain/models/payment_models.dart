import 'package:flutter/material.dart';
import 'package:get/get.dart';

// Modèle pour les résultats de paiement
class PaymentResult {
  final bool isSuccess;
  final String message;
  final Map<String, dynamic>? data;

  PaymentResult({
    required this.isSuccess,
    required this.message,
    this.data,
  });

  factory PaymentResult.success(String message, {Map<String, dynamic>? data}) {
    return PaymentResult(
      isSuccess: true,
      message: message,
      data: data,
    );
  }

  factory PaymentResult.error(String message, {Map<String, dynamic>? data}) {
    return PaymentResult(
      isSuccess: false,
      message: message,
      data: data,
    );
  }
}

// Modèle pour le statut de paiement
enum PaymentStatus {
  pending,
  completed,
  failed,
  cancelled,
  unknown,
}

// Modèle pour les méthodes de paiement
class PaymentMethod {
  final String id;
  final String name;
  final String? imageUrl;
  final String gateway;

  PaymentMethod({
    required this.id,
    required this.name,
    this.imageUrl,
    required this.gateway,
  });
}

// Interface de service de paiement
abstract class PaymentService {
  Future<bool> initializePayment();
  
  Future<PaymentResult> processPayment({
    required double amount,
    required String currency,
    required String transactionId,
    required String description,
    Map<String, dynamic>? metadata,
  });
  
  Future<PaymentStatus> checkPaymentStatus(String transactionId);
  
  List<PaymentMethod> getAvailablePaymentMethods();
}

// Configuration pour CinetPay
class CinetPayConfig {
  final String apiKey;
  final int siteId;
  final String notifyUrl;

  CinetPayConfig({
    required this.apiKey,
    required this.siteId,
    required this.notifyUrl,
  });
}

// Exception spécifique aux paiements
class PaymentException implements Exception {
  final String message;
  final String code;
  final dynamic details;
  
  PaymentException(this.message, {this.code = "", this.details});
  
  @override
  String toString() => "PaymentException: $message (Code: $code)";
}
