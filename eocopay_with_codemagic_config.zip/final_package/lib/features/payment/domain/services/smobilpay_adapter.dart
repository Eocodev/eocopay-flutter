import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';
import 'package:six_cash/features/payment/domain/models/payment_models.dart';
import 'package:six_cash/util/app_constants.dart';
import 'package:uuid/uuid.dart';

class SMobilPayConfig {
  final String publicAccessToken;
  final String accessSecret;
  final String environment;
  final String callbackUrl;

  SMobilPayConfig({
    required this.publicAccessToken,
    required this.accessSecret,
    this.environment = 'production',
    required this.callbackUrl,
  });

  String get baseUrl => environment == 'production'
      ? 'https://api.smobilpay.com/s3papi/v1'
      : 'https://api-test.smobilpay.com/s3papi/v1';
}

class SMobilPayAdapter implements PaymentService {
  final SMobilPayConfig config;
  
  SMobilPayAdapter(this.config);
  
  @override
  Future<bool> initializePayment() async {
    // Vérification de la configuration
    if (config.publicAccessToken.isEmpty || config.accessSecret.isEmpty) {
      throw PaymentException(
        "Configuration SMobilPay invalide",
        code: "INVALID_CONFIG",
      );
    }
    
    try {
      // Test de connexion à l'API avec un ping
      final response = await _makeApiRequest(
        method: 'GET',
        endpoint: '/ping',
      );
      
      if (response.statusCode == 200) {
        return true;
      } else {
        throw PaymentException(
          "Échec de l'initialisation SMobilPay",
          code: "INIT_FAILED",
          details: "Status code: ${response.statusCode}, Body: ${response.body}",
        );
      }
    } catch (e) {
      throw PaymentException(
        "Erreur lors de l'initialisation SMobilPay",
        code: "INIT_ERROR",
        details: e.toString(),
      );
    }
  }
  
  @override
  Future<PaymentResult> processPayment({
    required double amount,
    required String currency,
    required String transactionId,
    required String description,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      // Vérification des paramètres
      if (amount <= 0) {
        return PaymentResult.error("Le montant doit être supérieur à 0");
      }
      
      // Préparation des données pour l'initiation du paiement
      final Map<String, String> paymentData = {
        'amount': amount.toString(),
        'currency': currency,
        'external_reference': transactionId,
        'description': description,
        'callback_url': config.callbackUrl,
      };
      
      // Ajout des métadonnées si fournies
      if (metadata != null && metadata.isNotEmpty) {
        paymentData['metadata'] = jsonEncode(metadata);
      }
      
      // Initiation du paiement
      final response = await _makeApiRequest(
        method: 'POST',
        endpoint: '/payments/initiate',
        data: paymentData,
      );
      
      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        
        // Vérification de la réponse
        if (responseData['status'] == 'success') {
          final paymentUrl = responseData['payment_url'];
          final paymentId = responseData['payment_id'];
          
          // Redirection vers la page de paiement
          final paymentResult = await _showPaymentWebView(paymentUrl);
          
          // Vérification du statut du paiement
          if (paymentResult) {
            final statusResponse = await _checkPaymentStatus(paymentId);
            
            if (statusResponse['status'] == 'completed') {
              return PaymentResult.success(
                "Paiement réussi",
                data: statusResponse,
              );
            } else {
              return PaymentResult.error(
                "Paiement non complété: ${statusResponse['status']}",
                data: statusResponse,
              );
            }
          } else {
            return PaymentResult.error("Paiement annulé par l'utilisateur");
          }
        } else {
          return PaymentResult.error(
            "Échec de l'initiation du paiement: ${responseData['message'] ?? 'Erreur inconnue'}",
            data: responseData,
          );
        }
      } else {
        return PaymentResult.error(
          "Échec de la requête de paiement: ${response.statusCode}",
          data: {'body': response.body},
        );
      }
    } catch (e) {
      return PaymentResult.error("Erreur lors du traitement du paiement: ${e.toString()}");
    }
  }
  
  @override
  Future<PaymentStatus> checkPaymentStatus(String transactionId) async {
    try {
      final response = await _makeApiRequest(
        method: 'GET',
        endpoint: '/payments/status/$transactionId',
      );
      
      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        
        switch (responseData['status']) {
          case 'completed':
            return PaymentStatus.completed;
          case 'pending':
            return PaymentStatus.pending;
          case 'failed':
            return PaymentStatus.failed;
          case 'cancelled':
            return PaymentStatus.cancelled;
          default:
            return PaymentStatus.unknown;
        }
      } else {
        return PaymentStatus.unknown;
      }
    } catch (e) {
      return PaymentStatus.unknown;
    }
  }
  
  @override
  List<PaymentMethod> getAvailablePaymentMethods() {
    return [
      PaymentMethod(
        id: 'smobilpay_all',
        name: 'SMobilPay',
        imageUrl: '${AppConstants.BASE_URL}/assets/images/smobilpay_logo.png',
        gateway: 'smobilpay',
      ),
      PaymentMethod(
        id: 'smobilpay_mobile_money',
        name: 'Mobile Money (SMobilPay)',
        imageUrl: '${AppConstants.BASE_URL}/assets/images/mobile_money.png',
        gateway: 'smobilpay',
      ),
      PaymentMethod(
        id: 'smobilpay_orange_money',
        name: 'Orange Money (SMobilPay)',
        imageUrl: '${AppConstants.BASE_URL}/assets/images/orange_money.png',
        gateway: 'smobilpay',
      ),
    ];
  }
  
  // Méthodes privées pour l'API SMobilPay
  
  Future<http.Response> _makeApiRequest({
    required String method,
    required String endpoint,
    Map<String, String>? data,
  }) async {
    final url = Uri.parse('${config.baseUrl}$endpoint');
    
    // Génération de la signature selon la norme d'autorisation S3P
    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final nonce = Uuid().v4();
    
    // Construction de la chaîne à signer
    String stringToSign = method + '\n' + url.toString() + '\n' + timestamp + '\n' + nonce;
    
    // Ajout des données si présentes (pour les requêtes POST)
    if (data != null && data.isNotEmpty) {
      // Tri des clés par ordre alphabétique
      final sortedKeys = data.keys.toList()..sort();
      final sortedData = {for (var k in sortedKeys) k: data[k]};
      
      // Ajout des données à la chaîne à signer
      stringToSign += '\n' + jsonEncode(sortedData);
    }
    
    // Génération de la signature HMAC-SHA256
    final key = utf8.encode(config.accessSecret);
    final bytes = utf8.encode(stringToSign);
    final hmacSha256 = Hmac(sha256, key);
    final digest = hmacSha256.convert(bytes);
    final signature = base64.encode(digest.bytes);
    
    // En-têtes d'autorisation
    final headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'S3P ${config.publicAccessToken}:$signature:$nonce:$timestamp',
    };
    
    // Exécution de la requête
    if (method == 'GET') {
      return await http.get(url, headers: headers);
    } else if (method == 'POST') {
      return await http.post(
        url,
        headers: headers,
        body: data,
      );
    } else {
      throw PaymentException("Méthode HTTP non supportée: $method");
    }
  }
  
  Future<Map<String, dynamic>> _checkPaymentStatus(String paymentId) async {
    final response = await _makeApiRequest(
      method: 'GET',
      endpoint: '/payments/status/$paymentId',
    );
    
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw PaymentException(
        "Échec de la vérification du statut du paiement",
        code: "STATUS_CHECK_FAILED",
        details: "Status code: ${response.statusCode}, Body: ${response.body}",
      );
    }
  }
  
  Future<bool> _showPaymentWebView(String paymentUrl) async {
    // Cette méthode devrait afficher une WebView pour le paiement
    // et retourner true si le paiement est complété, false sinon
    // Pour l'instant, nous simulons un paiement réussi
    return true;
  }
  
  // Méthode utilitaire pour générer un ID de transaction unique
  String generateTransactionId() {
    final uuid = Uuid();
    return 'SMOBILPAY_${uuid.v4().substring(0, 8)}_${DateTime.now().millisecondsSinceEpoch}';
  }
}
