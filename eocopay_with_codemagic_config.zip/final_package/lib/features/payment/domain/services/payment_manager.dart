import 'package:six_cash/features/payment/domain/models/payment_models.dart';
import 'package:six_cash/features/payment/domain/services/cinetpay_adapter.dart';
import 'package:uuid/uuid.dart';

class PaymentManager {
  final Map<String, PaymentService> _paymentServices;
  
  PaymentManager(this._paymentServices);
  
  List<PaymentMethod> getAllPaymentMethods() {
    List<PaymentMethod> methods = [];
    for (var service in _paymentServices.values) {
      methods.addAll(service.getAvailablePaymentMethods());
    }
    return methods;
  }
  
  Future<PaymentResult> processPayment({
    required String paymentMethodId,
    required double amount,
    required String currency,
    required String description,
    Map<String, dynamic>? metadata,
  }) async {
    final String serviceKey = _getServiceKeyForMethod(paymentMethodId);
    final service = _paymentServices[serviceKey];
    
    if (service == null) {
      return PaymentResult.error("Méthode de paiement non prise en charge");
    }
    
    final transactionId = _generateTransactionId(serviceKey);
    
    return service.processPayment(
      amount: amount,
      currency: currency,
      transactionId: transactionId,
      description: description,
      metadata: metadata,
    );
  }
  
  Future<bool> initializeAllServices() async {
    bool allInitialized = true;
    
    for (var service in _paymentServices.values) {
      try {
        bool initialized = await service.initializePayment();
        if (!initialized) {
          allInitialized = false;
        }
      } catch (e) {
        allInitialized = false;
        print("Erreur d'initialisation du service de paiement: $e");
      }
    }
    
    return allInitialized;
  }
  
  Future<PaymentStatus> checkPaymentStatus(String transactionId) async {
    // Extraire le préfixe du service à partir de l'ID de transaction
    String? serviceKey;
    
    for (var key in _paymentServices.keys) {
      if (transactionId.startsWith("${key.toUpperCase()}_")) {
        serviceKey = key;
        break;
      }
    }
    
    if (serviceKey == null || !_paymentServices.containsKey(serviceKey)) {
      return PaymentStatus.unknown;
    }
    
    return _paymentServices[serviceKey]!.checkPaymentStatus(transactionId);
  }
  
  // Méthodes utilitaires
  
  String _getServiceKeyForMethod(String paymentMethodId) {
    if (paymentMethodId.startsWith('cinetpay_')) {
      return 'cinetpay';
    } else if (paymentMethodId.startsWith('smobilpay_')) {
      return 'smobilpay';
    }
    
    // Fallback pour les méthodes de paiement existantes
    return 'default';
  }
  
  String _generateTransactionId(String serviceKey) {
    final uuid = Uuid();
    return '${serviceKey.toUpperCase()}_${uuid.v4().substring(0, 8)}_${DateTime.now().millisecondsSinceEpoch}';
  }
}
