import 'package:flutter/material.dart';
import 'package:cinetpay/cinetpay.dart';
import 'package:six_cash/features/payment/domain/models/payment_models.dart';
import 'package:six_cash/util/app_constants.dart';
import 'package:uuid/uuid.dart';

class CinetPayAdapter implements PaymentService {
  final CinetPayConfig config;
  
  CinetPayAdapter(this.config);
  
  @override
  Future<bool> initializePayment() async {
    // Vérification de la configuration
    if (config.apiKey.isEmpty || config.siteId <= 0 || config.notifyUrl.isEmpty) {
      throw PaymentException(
        "Configuration CinetPay invalide",
        code: "INVALID_CONFIG",
      );
    }
    
    return true;
  }
  
  @override
  Future<PaymentResult> processPayment({
    required double amount,
    required String currency,
    required String transactionId,
    required String description,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      // Vérification des paramètres
      if (amount < 100) {
        return PaymentResult.error("Le montant minimum est de 100");
      }
      
      if (!['XOF', 'XAF', 'GNF', 'USD'].contains(currency)) {
        return PaymentResult.error("Devise non prise en charge: $currency");
      }
      
      // Préparation des données pour CinetPay
      final Map<String, dynamic> configData = {
        'apikey': config.apiKey,
        'site_id': config.siteId,
        'notify_url': config.notifyUrl,
      };
      
      final Map<String, dynamic> paymentData = {
        'transaction_id': transactionId,
        'amount': amount,
        'currency': currency,
        'channels': 'ALL',
        'description': description,
      };
      
      // Ajout des métadonnées si fournies
      if (metadata != null && metadata.isNotEmpty) {
        paymentData['metadata'] = metadata.toString();
      }
      
      // Création d'un BuildContext temporaire pour afficher le widget CinetPay
      final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
      
      // Résultat du paiement
      Map<String, dynamic>? paymentResponse;
      
      // Affichage du widget CinetPay dans une nouvelle route
      await Navigator.of(navigatorKey.currentContext!).push(
        MaterialPageRoute(
          builder: (context) => Scaffold(
            appBar: AppBar(
              title: Text('Paiement via CinetPay'),
              leading: IconButton(
                icon: Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            body: CinetPayCheckout(
              title: 'Paiement',
              configData: configData,
              paymentData: paymentData,
              waitResponse: (response) {
                paymentResponse = response;
                Navigator.pop(context);
              },
              onError: (error) {
                paymentResponse = {
                  'status': 'REFUSED',
                  'message': error['message'] ?? 'Erreur de paiement',
                };
                Navigator.pop(context);
              },
            ),
          ),
        ),
      );
      
      // Traitement de la réponse
      if (paymentResponse == null) {
        return PaymentResult.error("Paiement annulé");
      }
      
      if (paymentResponse!['status'] == 'ACCEPTED') {
        return PaymentResult.success(
          "Paiement réussi",
          data: paymentResponse,
        );
      } else {
        return PaymentResult.error(
          paymentResponse!['message'] ?? "Échec du paiement",
          data: paymentResponse,
        );
      }
    } catch (e) {
      return PaymentResult.error("Erreur lors du traitement du paiement: ${e.toString()}");
    }
  }
  
  @override
  Future<PaymentStatus> checkPaymentStatus(String transactionId) async {
    // Cette fonctionnalité nécessiterait un appel API supplémentaire à CinetPay
    // Pour l'instant, nous retournons un statut inconnu
    return PaymentStatus.unknown;
  }
  
  @override
  List<PaymentMethod> getAvailablePaymentMethods() {
    return [
      PaymentMethod(
        id: 'cinetpay_all',
        name: 'CinetPay',
        imageUrl: '${AppConstants.BASE_URL}/assets/images/cinetpay_logo.png',
        gateway: 'cinetpay',
      ),
      PaymentMethod(
        id: 'cinetpay_mobile_money',
        name: 'Mobile Money (CinetPay)',
        imageUrl: '${AppConstants.BASE_URL}/assets/images/mobile_money.png',
        gateway: 'cinetpay',
      ),
      PaymentMethod(
        id: 'cinetpay_card',
        name: 'Carte Bancaire (CinetPay)',
        imageUrl: '${AppConstants.BASE_URL}/assets/images/credit_card.png',
        gateway: 'cinetpay',
      ),
    ];
  }
  
  // Méthode utilitaire pour générer un ID de transaction unique
  String generateTransactionId() {
    final uuid = Uuid();
    return 'CINETPAY_${uuid.v4().substring(0, 8)}_${DateTime.now().millisecondsSinceEpoch}';
  }
}
