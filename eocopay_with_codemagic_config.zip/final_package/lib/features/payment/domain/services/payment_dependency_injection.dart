import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/payment/domain/models/payment_models.dart';
import 'package:six_cash/features/payment/domain/services/payment_manager.dart';
import 'package:six_cash/features/payment/domain/services/cinetpay_adapter.dart';
import 'package:six_cash/features/payment/domain/services/smobilpay_adapter.dart';
import 'package:six_cash/util/app_constants.dart';
import 'package:six_cash/util/images.dart';

class PaymentDependencyInjection {
  static void init() {
    // Configuration de CinetPay
    final cinetPayConfig = CinetPayConfig(
      apiKey: AppConstants.CINETPAY_API_KEY,
      siteId: AppConstants.CINETPAY_SITE_ID,
      notifyUrl: AppConstants.CINETPAY_NOTIFY_URL,
    );
    
    // Configuration de SMobilPay
    final sMobilPayConfig = SMobilPayConfig(
      publicAccessToken: AppConstants.SMOBILPAY_PUBLIC_TOKEN,
      accessSecret: AppConstants.SMOBILPAY_ACCESS_SECRET,
      environment: AppConstants.SMOBILPAY_ENVIRONMENT,
      callbackUrl: AppConstants.SMOBILPAY_CALLBACK_URL,
    );
    
    // Création des adaptateurs
    final cinetPayAdapter = CinetPayAdapter(cinetPayConfig);
    final sMobilPayAdapter = SMobilPayAdapter(sMobilPayConfig);
    
    // Création et enregistrement du gestionnaire de paiement
    final paymentManager = PaymentManager({
      'cinetpay': cinetPayAdapter,
      'smobilpay': sMobilPayAdapter,
    });
    
    // Enregistrement dans GetX
    Get.lazyPut<PaymentManager>(() => paymentManager, fenix: true);
  }
}
