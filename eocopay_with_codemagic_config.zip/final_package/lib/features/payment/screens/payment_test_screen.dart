import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/payment/domain/models/payment_models.dart';
import 'package:six_cash/features/payment/domain/services/payment_manager.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/common/widgets/custom_app_bar.dart';
import 'package:six_cash/common/widgets/custom_button.dart';
import 'package:six_cash/common/widgets/custom_snackbar.dart';

class PaymentTestScreen extends StatefulWidget {
  const PaymentTestScreen({Key? key}) : super(key: key);

  @override
  State<PaymentTestScreen> createState() => _PaymentTestScreenState();
}

class _PaymentTestScreenState extends State<PaymentTestScreen> {
  final List<double> _testAmounts = [100, 500, 1000];
  String? _selectedPaymentMethod;
  bool _isLoading = false;
  PaymentResult? _lastResult;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Test des passerelles de paiement'),
      body: GetBuilder<PaymentManager>(
        builder: (paymentManager) {
          // Récupérer toutes les méthodes de paiement disponibles
          final List<PaymentMethod> paymentMethods = paymentManager.getAllPaymentMethods();
          
          return Padding(
            padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Section d'information
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                  ),
                  child: Text(
                    'Cet écran permet de tester les différentes passerelles de paiement intégrées dans l\'application. Sélectionnez une méthode de paiement et un montant pour effectuer un test.',
                    style: rubikRegular,
                  ),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),
                
                // Sélection de la méthode de paiement
                Text(
                  'Méthode de paiement',
                  style: rubikMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                    border: Border.all(color: Theme.of(context).primaryColor.withOpacity(0.3)),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedPaymentMethod,
                      hint: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
                        child: Text('Sélectionnez une méthode de paiement'),
                      ),
                      isExpanded: true,
                      borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                      items: paymentMethods.map((method) {
                        return DropdownMenuItem<String>(
                          value: method.id,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
                            child: Text(method.name),
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedPaymentMethod = value;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),
                
                // Sélection du montant
                Text(
                  'Montant de test',
                  style: rubikMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                
                Row(
                  children: _testAmounts.map((amount) {
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraSmall),
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : () => _testPayment(paymentManager, amount),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).primaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                            ),
                          ),
                          child: Text(
                            '${amount.toStringAsFixed(0)} FCFA',
                            style: rubikMedium.copyWith(color: Colors.white),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),
                
                // Résultat du test
                if (_lastResult != null)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                    decoration: BoxDecoration(
                      color: _lastResult!.isSuccess
                          ? Colors.green.withOpacity(0.1)
                          : Colors.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _lastResult!.isSuccess ? 'Test réussi' : 'Échec du test',
                          style: rubikMedium.copyWith(
                            color: _lastResult!.isSuccess ? Colors.green : Colors.red,
                            fontSize: Dimensions.fontSizeLarge,
                          ),
                        ),
                        const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                        Text(
                          _lastResult!.message,
                          style: rubikRegular.copyWith(
                            color: _lastResult!.isSuccess ? Colors.green : Colors.red,
                          ),
                        ),
                        if (_lastResult!.data != null) ...[
                          const SizedBox(height: Dimensions.paddingSizeSmall),
                          Text(
                            'Détails de la transaction:',
                            style: rubikMedium,
                          ),
                          const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                          Text(
                            _lastResult!.data.toString(),
                            style: rubikRegular.copyWith(fontSize: Dimensions.fontSizeSmall),
                          ),
                        ],
                      ],
                    ),
                  ),
                
                const Spacer(),
                
                // Bouton pour effacer les résultats
                if (_lastResult != null)
                  CustomButton(
                    buttonText: 'Effacer les résultats',
                    onPressed: () {
                      setState(() {
                        _lastResult = null;
                      });
                    },
                    backgroundColor: Colors.grey,
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
  
  Future<void> _testPayment(PaymentManager paymentManager, double amount) async {
    if (_selectedPaymentMethod == null) {
      showCustomSnackBar('Veuillez sélectionner une méthode de paiement');
      return;
    }
    
    setState(() {
      _isLoading = true;
      _lastResult = null;
    });
    
    try {
      // Déterminer la devise en fonction de la méthode de paiement
      String currency = 'XOF'; // Par défaut
      if (_selectedPaymentMethod!.startsWith('smobilpay')) {
        currency = 'XAF';
      }
      
      final result = await paymentManager.processPayment(
        paymentMethodId: _selectedPaymentMethod!,
        amount: amount,
        currency: currency,
        description: 'Test de paiement',
      );
      
      setState(() {
        _lastResult = result;
      });
    } catch (e) {
      setState(() {
        _lastResult = PaymentResult.error('Erreur lors du test: ${e.toString()}');
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
}
