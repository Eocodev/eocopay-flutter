import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/payment/screens/payment_test_screen.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/common/widgets/custom_app_bar.dart';
import 'package:six_cash/common/widgets/custom_button.dart';

class PaymentTestMenuScreen extends StatelessWidget {
  const PaymentTestMenuScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Tests des passerelles de paiement'),
      body: Padding(
        padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Section d'information
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Tests des passerelles de paiement',
                    style: rubikMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                  ),
                  const SizedBox(height: Dimensions.paddingSizeSmall),
                  Text(
                    'Cette section permet de tester les différentes passerelles de paiement intégrées dans l\'application. Vous pouvez tester chaque passerelle individuellement ou utiliser l\'interface unifiée.',
                    style: rubikRegular,
                  ),
                ],
              ),
            ),
            const SizedBox(height: Dimensions.paddingSizeLarge),
            
            // Liste des tests disponibles
            Expanded(
              child: ListView(
                children: [
                  _buildTestCard(
                    context,
                    title: 'Test de CinetPay',
                    description: 'Tester l\'intégration de la passerelle CinetPay avec différents montants et méthodes de paiement.',
                    icon: Icons.payment,
                    onTap: () => Get.to(() => PaymentTestScreen()),
                  ),
                  const SizedBox(height: Dimensions.paddingSizeSmall),
                  
                  _buildTestCard(
                    context,
                    title: 'Test de SMobilPay',
                    description: 'Tester l\'intégration de la passerelle SMobilPay avec différents montants et méthodes de paiement.',
                    icon: Icons.mobile_friendly,
                    onTap: () => Get.to(() => PaymentTestScreen()),
                  ),
                  const SizedBox(height: Dimensions.paddingSizeSmall),
                  
                  _buildTestCard(
                    context,
                    title: 'Test de l\'interface unifiée',
                    description: 'Tester l\'interface de paiement unifiée qui permet de choisir entre les différentes passerelles.',
                    icon: Icons.dashboard_customize,
                    onTap: () => Get.to(() => PaymentTestScreen()),
                  ),
                  const SizedBox(height: Dimensions.paddingSizeSmall),
                  
                  _buildTestCard(
                    context,
                    title: 'Test de connectivité',
                    description: 'Tester le comportement des passerelles de paiement en mode hors ligne et en ligne.',
                    icon: Icons.wifi_off,
                    onTap: () => Get.to(() => PaymentTestScreen()),
                  ),
                ],
              ),
            ),
            
            // Bouton pour revenir à l'écran principal
            CustomButton(
              buttonText: 'Retour à l\'écran principal',
              onPressed: () => Get.back(),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildTestCard(
    BuildContext context, {
    required String title,
    required String description,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
        child: Padding(
          padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                ),
                child: Icon(
                  icon,
                  color: Theme.of(context).primaryColor,
                  size: 30,
                ),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: rubikMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                    Text(
                      description,
                      style: rubikRegular.copyWith(
                        fontSize: Dimensions.fontSizeSmall,
                        color: Theme.of(context).hintColor,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: Theme.of(context).primaryColor,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
