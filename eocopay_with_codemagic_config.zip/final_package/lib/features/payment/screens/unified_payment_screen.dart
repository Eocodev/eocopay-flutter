import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/payment/domain/models/payment_models.dart';
import 'package:six_cash/features/payment/domain/services/payment_manager.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/common/widgets/custom_app_bar.dart';
import 'package:six_cash/common/widgets/custom_button.dart';
import 'package:six_cash/common/widgets/custom_loader.dart';
import 'package:six_cash/common/widgets/custom_snackbar.dart';
import 'package:six_cash/features/add_money/controllers/add_money_controller.dart';

class UnifiedPaymentScreen extends StatefulWidget {
  final double amount;
  final String? selectedPaymentMethod;
  
  const UnifiedPaymentScreen({
    Key? key,
    required this.amount,
    this.selectedPaymentMethod,
  }) : super(key: key);

  @override
  State<UnifiedPaymentScreen> createState() => _UnifiedPaymentScreenState();
}

class _UnifiedPaymentScreenState extends State<UnifiedPaymentScreen> {
  String? _selectedPaymentMethod;
  bool _isLoading = false;
  
  @override
  void initState() {
    super.initState();
    _selectedPaymentMethod = widget.selectedPaymentMethod;
    
    // Initialiser le contrôleur avec la méthode de paiement sélectionnée
    if (_selectedPaymentMethod != null) {
      Get.find<AddMoneyController>().setPaymentMethod(_selectedPaymentMethod);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Choisir un moyen de paiement'),
      body: GetBuilder<AddMoneyController>(
        builder: (addMoneyController) {
          return GetBuilder<PaymentManager>(
            builder: (paymentManager) {
              // Récupérer toutes les méthodes de paiement disponibles
              final List<PaymentMethod> paymentMethods = paymentManager.getAllPaymentMethods();
              
              return Stack(
                children: [
                  Column(
                    children: [
                      // Montant à payer
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                        margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                        decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                        ),
                        child: Column(
                          children: [
                            Text(
                              'Montant à payer',
                              style: rubikMedium.copyWith(
                                fontSize: Dimensions.fontSizeLarge,
                                color: Theme.of(context).primaryColor,
                              ),
                            ),
                            const SizedBox(height: Dimensions.paddingSizeSmall),
                            Text(
                              '${widget.amount.toStringAsFixed(2)} FCFA',
                              style: rubikBold.copyWith(
                                fontSize: Dimensions.fontSizeOverLarge,
                                color: Theme.of(context).primaryColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Liste des méthodes de paiement
                      Expanded(
                        child: ListView.builder(
                          itemCount: paymentMethods.length,
                          padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                          itemBuilder: (context, index) {
                            final PaymentMethod method = paymentMethods[index];
                            
                            return Card(
                              margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                                side: BorderSide(
                                  color: _selectedPaymentMethod == method.id
                                      ? Theme.of(context).primaryColor
                                      : Colors.transparent,
                                  width: 2,
                                ),
                              ),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    _selectedPaymentMethod = method.id;
                                  });
                                  addMoneyController.setPaymentMethod(method.id);
                                },
                                borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                                child: Padding(
                                  padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                                  child: Row(
                                    children: [
                                      // Logo de la méthode de paiement
                                      Container(
                                        height: 60,
                                        width: 60,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                                          color: Colors.grey.withOpacity(0.1),
                                        ),
                                        padding: const EdgeInsets.all(Dimensions.paddingSizeExtraSmall),
                                        child: method.imageUrl != null
                                            ? Image.network(
                                                method.imageUrl!,
                                                errorBuilder: (context, error, stackTrace) => 
                                                    Icon(Icons.payment, color: Theme.of(context).primaryColor),
                                              )
                                            : Icon(Icons.payment, color: Theme.of(context).primaryColor),
                                      ),
                                      
                                      const SizedBox(width: Dimensions.paddingSizeSmall),
                                      
                                      // Nom de la méthode de paiement
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              method.name,
                                              style: rubikMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                                            ),
                                            if (method.id.contains('mobile_money'))
                                              Text(
                                                'Paiement via Mobile Money',
                                                style: rubikRegular.copyWith(
                                                  fontSize: Dimensions.fontSizeSmall,
                                                  color: Theme.of(context).hintColor,
                                                ),
                                              ),
                                            if (method.id.contains('card'))
                                              Text(
                                                'Paiement par carte bancaire',
                                                style: rubikRegular.copyWith(
                                                  fontSize: Dimensions.fontSizeSmall,
                                                  color: Theme.of(context).hintColor,
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                      
                                      // Indicateur de sélection
                                      Radio<String>(
                                        value: method.id,
                                        groupValue: _selectedPaymentMethod,
                                        onChanged: (value) {
                                          setState(() {
                                            _selectedPaymentMethod = value;
                                          });
                                          addMoneyController.setPaymentMethod(value);
                                        },
                                        activeColor: Theme.of(context).primaryColor,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      
                      // Bouton de paiement
                      Padding(
                        padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                        child: CustomButton(
                          buttonText: 'Procéder au paiement',
                          onPressed: _selectedPaymentMethod == null ? null : () => _processPayment(addMoneyController),
                        ),
                      ),
                    ],
                  ),
                  
                  // Indicateur de chargement
                  if (_isLoading || addMoneyController.isLoading)
                    const CustomLoader(),
                ],
              );
            },
          );
        },
      ),
    );
  }
  
  void _processPayment(AddMoneyController addMoneyController) async {
    if (_selectedPaymentMethod == null) {
      showCustomSnackBar('Veuillez sélectionner une méthode de paiement');
      return;
    }
    
    setState(() {
      _isLoading = true;
    });
    
    await addMoneyController.addMoney(widget.amount);
    
    setState(() {
      _isLoading = false;
    });
    
    // Vérifier le résultat du paiement
    if (addMoneyController.lastPaymentResult != null) {
      if (addMoneyController.lastPaymentResult!.isSuccess) {
        showCustomSnackBar(
          'Paiement réussi: ${addMoneyController.lastPaymentResult!.message}',
          isError: false,
        );
        
        // Retourner à l'écran précédent avec le résultat
        Future.delayed(const Duration(seconds: 2), () {
          Get.back(result: true);
        });
      } else {
        showCustomSnackBar(
          'Échec du paiement: ${addMoneyController.lastPaymentResult!.message}',
          isError: true,
        );
      }
    }
  }
}
