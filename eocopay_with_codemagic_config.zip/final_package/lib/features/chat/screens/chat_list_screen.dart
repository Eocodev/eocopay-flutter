import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/chat/domain/models/chat_conversation_model.dart';
import 'package:six_cash/features/chat/controllers/chat_list_controller.dart';
import 'package:six_cash/features/chat/screens/chat_detail_screen.dart';
import 'package:six_cash/common/widgets/offline_mode_banner.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/util/color_resources.dart';
import 'package:six_cash/util/images.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({Key? key}) : super(key: key);

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  final ChatListController _chatListController = Get.put(ChatListController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Messages', style: rubikMedium.copyWith(fontSize: 18)),
        backgroundColor: ColorResources.getPrimaryColor(),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // Implémentation de la recherche
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Bannière mode hors ligne
          const OfflineModeBanner(),
          
          // Liste des conversations
          Expanded(
            child: Obx(() {
              if (_chatListController.isLoading) {
                return const Center(child: CircularProgressIndicator());
              }
              
              if (_chatListController.conversations.isEmpty) {
                return _buildEmptyState();
              }
              
              return RefreshIndicator(
                onRefresh: _chatListController.refreshConversations,
                child: ListView.builder(
                  itemCount: _chatListController.conversations.length,
                  itemBuilder: (context, index) {
                    return _buildConversationItem(
                      _chatListController.conversations[index],
                    );
                  },
                ),
              );
            }),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showNewChatDialog(context);
        },
        backgroundColor: ColorResources.getPrimaryColor(),
        child: const Icon(Icons.chat),
      ),
    );
  }

  Widget _buildConversationItem(ChatConversationModel conversation) {
    return Dismissible(
      key: Key(conversation.id),
      background: Container(
        color: Colors.red,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      direction: DismissDirection.endToStart,
      confirmDismiss: (direction) async {
        return await showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Confirmer la suppression'),
              content: const Text('Voulez-vous vraiment supprimer cette conversation ?'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Annuler'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text('Supprimer'),
                ),
              ],
            );
          },
        );
      },
      onDismissed: (direction) {
        _chatListController.deleteConversation(conversation.id);
      },
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage: conversation.participantAvatar != null && conversation.participantAvatar!.isNotEmpty
              ? NetworkImage(conversation.participantAvatar!)
              : null,
          child: conversation.participantAvatar == null || conversation.participantAvatar!.isEmpty
              ? Text(conversation.participantName.substring(0, 1).toUpperCase())
              : null,
          backgroundColor: ColorResources.getSecondaryColor(),
        ),
        title: Text(
          conversation.participantName,
          style: rubikMedium.copyWith(fontSize: 16),
        ),
        subtitle: Row(
          children: [
            // Icône indiquant la source du message
            _getSourceIcon(conversation.preferredSource),
            const SizedBox(width: 4),
            // Contenu du dernier message
            Expanded(
              child: Text(
                conversation.lastMessageContent,
                style: rubikRegular.copyWith(
                  fontSize: 14,
                  color: conversation.hasUnreadMessages
                      ? ColorResources.getPrimaryColor()
                      : Colors.grey,
                  fontWeight: conversation.hasUnreadMessages
                      ? FontWeight.bold
                      : FontWeight.normal,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Heure du dernier message
            Text(
              _formatTime(conversation.lastMessageTime),
              style: rubikRegular.copyWith(
                fontSize: 12,
                color: conversation.hasUnreadMessages
                    ? ColorResources.getPrimaryColor()
                    : Colors.grey,
              ),
            ),
            const SizedBox(height: 4),
            // Badge de messages non lus
            if (conversation.hasUnreadMessages)
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: ColorResources.getPrimaryColor(),
                  shape: BoxShape.circle,
                ),
                child: Text(
                  conversation.unreadCount.toString(),
                  style: rubikRegular.copyWith(
                    fontSize: 10,
                    color: Colors.white,
                  ),
                ),
              ),
          ],
        ),
        onTap: () {
          // Marquer la conversation comme lue
          _chatListController.markConversationAsRead(conversation.id);
          
          // Naviguer vers l'écran de détail de la conversation
          Get.to(() => ChatDetailScreen(
            conversationId: conversation.id,
            participantName: conversation.participantName,
            participantAvatar: conversation.participantAvatar,
          ));
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            Images.noData, // Utiliser une image existante ou en ajouter une nouvelle
            width: 150,
            height: 150,
          ),
          const SizedBox(height: 20),
          Text(
            'Aucune conversation',
            style: rubikMedium.copyWith(fontSize: 18),
          ),
          const SizedBox(height: 10),
          Text(
            'Commencez une nouvelle conversation en appuyant sur le bouton ci-dessous',
            style: rubikRegular.copyWith(fontSize: 14, color: Colors.grey),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _getSourceIcon(MessageSource source) {
    IconData iconData;
    Color iconColor;
    
    switch (source) {
      case MessageSource.sms:
        iconData = Icons.sms;
        iconColor = Colors.green;
        break;
      case MessageSource.rcs:
        iconData = Icons.chat;
        iconColor = Colors.blue;
        break;
      case MessageSource.online:
      default:
        iconData = Icons.cloud;
        iconColor = ColorResources.getPrimaryColor();
        break;
    }
    
    return Icon(
      iconData,
      size: 14,
      color: iconColor,
    );
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final messageDate = DateTime(dateTime.year, dateTime.month, dateTime.day);
    
    if (messageDate == today) {
      // Aujourd'hui, afficher l'heure
      return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else if (messageDate == yesterday) {
      // Hier
      return 'Hier';
    } else {
      // Autre date
      return '${dateTime.day.toString().padLeft(2, '0')}/${dateTime.month.toString().padLeft(2, '0')}';
    }
  }

  void _showNewChatDialog(BuildContext context) {
    final TextEditingController phoneController = TextEditingController();
    final TextEditingController nameController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Nouvelle conversation'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: 'Numéro de téléphone',
                  hintText: 'Ex: +33612345678',
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 10),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Nom du contact',
                  hintText: 'Ex: Jean Dupont',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Annuler'),
            ),
            TextButton(
              onPressed: () {
                if (phoneController.text.isNotEmpty && nameController.text.isNotEmpty) {
                  _chatListController.createNewConversation(
                    phoneController.text,
                    nameController.text,
                  );
                  Navigator.of(context).pop();
                }
              },
              child: const Text('Créer'),
            ),
          ],
        );
      },
    );
  }
}
