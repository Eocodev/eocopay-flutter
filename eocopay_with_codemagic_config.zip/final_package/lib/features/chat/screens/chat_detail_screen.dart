import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';
import 'package:six_cash/features/chat/controllers/chat_detail_controller.dart';
import 'package:six_cash/common/widgets/offline_mode_banner.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/util/color_resources.dart';
import 'package:six_cash/util/images.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/foundation.dart' as foundation;

class ChatDetailScreen extends StatefulWidget {
  final String conversationId;
  final String participantName;
  final String? participantAvatar;

  const ChatDetailScreen({
    Key? key,
    required this.conversationId,
    required this.participantName,
    this.participantAvatar,
  }) : super(key: key);

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final ChatDetailController _chatDetailController = Get.put(ChatDetailController());
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _showEmojiPicker = false;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _chatDetailController.initConversation(
      widget.conversationId,
      widget.participantName,
      participantAvatar: widget.participantAvatar,
    );
    
    // Faire défiler vers le bas lorsque le clavier apparaît
    _focusNode.addListener(() {
      if (_focusNode.hasFocus) {
        setState(() {
          _showEmojiPicker = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: widget.participantAvatar != null && widget.participantAvatar!.isNotEmpty
                  ? NetworkImage(widget.participantAvatar!)
                  : null,
              child: widget.participantAvatar == null || widget.participantAvatar!.isEmpty
                  ? Text(widget.participantName.substring(0, 1).toUpperCase())
                  : null,
              backgroundColor: ColorResources.getSecondaryColor(),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.participantName,
                    style: rubikMedium.copyWith(fontSize: 16),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Obx(() {
                    String statusText = 'En ligne';
                    if (_chatDetailController.isOffline) {
                      statusText = 'Hors ligne (SMS)';
                    } else if (_chatDetailController.currentMessageSource == MessageSource.rcs) {
                      statusText = 'RCS';
                    }
                    return Text(
                      statusText,
                      style: rubikRegular.copyWith(fontSize: 12, color: Colors.white70),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: ColorResources.getPrimaryColor(),
        elevation: 0,
        actions: [
          PopupMenuButton<MessageSource>(
            onSelected: (MessageSource source) {
              _chatDetailController.changeMessageSource(source);
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<MessageSource>>[
              const PopupMenuItem<MessageSource>(
                value: MessageSource.online,
                child: Text('En ligne'),
              ),
              const PopupMenuItem<MessageSource>(
                value: MessageSource.sms,
                child: Text('SMS'),
              ),
              const PopupMenuItem<MessageSource>(
                value: MessageSource.rcs,
                child: Text('RCS'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Bannière mode hors ligne
          const OfflineModeBanner(),
          
          // Liste des messages
          Expanded(
            child: Obx(() {
              if (_chatDetailController.isLoading) {
                return const Center(child: CircularProgressIndicator());
              }
              
              if (_chatDetailController.messages.isEmpty) {
                return _buildEmptyState();
              }
              
              WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
              
              return ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.all(16),
                itemCount: _chatDetailController.messages.length,
                itemBuilder: (context, index) {
                  return _buildMessageItem(
                    _chatDetailController.messages[index],
                  );
                },
              );
            }),
          ),
          
          // Séparateur
          const Divider(height: 1),
          
          // Zone de saisie de message
          _buildMessageInput(),
          
          // Sélecteur d'emoji
          if (_showEmojiPicker) _buildEmojiPicker(),
        ],
      ),
    );
  }

  Widget _buildMessageItem(ChatMessageModel message) {
    final bool isMe = message.senderId == 'current_user';
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Avatar pour les messages reçus
          if (!isMe) ...[
            CircleAvatar(
              backgroundImage: widget.participantAvatar != null && widget.participantAvatar!.isNotEmpty
                  ? NetworkImage(widget.participantAvatar!)
                  : null,
              child: widget.participantAvatar == null || widget.participantAvatar!.isEmpty
                  ? Text(widget.participantName.substring(0, 1).toUpperCase())
                  : null,
              radius: 16,
              backgroundColor: ColorResources.getSecondaryColor(),
            ),
            const SizedBox(width: 8),
          ],
          
          // Contenu du message
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: isMe
                    ? ColorResources.getPrimaryColor().withOpacity(0.8)
                    : Colors.grey.shade200,
                borderRadius: BorderRadius.circular(20),
                borderTopRight: isMe ? const Radius.circular(4) : null,
                borderTopLeft: !isMe ? const Radius.circular(4) : null,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Contenu du message
                  _buildMessageContent(message),
                  
                  // Heure et statut
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _formatTime(message.timestamp),
                        style: rubikRegular.copyWith(
                          fontSize: 10,
                          color: isMe ? Colors.white70 : Colors.grey,
                        ),
                      ),
                      const SizedBox(width: 4),
                      if (isMe) _buildMessageStatus(message.status),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          // Indicateur de source de message
          const SizedBox(width: 4),
          _getSourceIcon(message.source),
        ],
      ),
    );
  }

  Widget _buildMessageContent(ChatMessageModel message) {
    switch (message.type) {
      case MessageType.emoji:
        return Text(
          message.content,
          style: const TextStyle(fontSize: 30),
        );
      case MessageType.image:
        // Implémentation pour les images
        return const Text("Image non disponible");
      case MessageType.text:
      default:
        return Text(
          message.content,
          style: rubikRegular.copyWith(
            fontSize: 16,
            color: message.senderId == 'current_user' ? Colors.white : Colors.black,
          ),
        );
    }
  }

  Widget _buildMessageStatus(MessageStatus status) {
    IconData iconData;
    Color iconColor = Colors.white70;
    
    switch (status) {
      case MessageStatus.sending:
        iconData = Icons.access_time;
        break;
      case MessageStatus.sent:
        iconData = Icons.check;
        break;
      case MessageStatus.delivered:
        iconData = Icons.done_all;
        break;
      case MessageStatus.read:
        iconData = Icons.done_all;
        iconColor = Colors.blue;
        break;
      case MessageStatus.failed:
        iconData = Icons.error_outline;
        iconColor = Colors.red;
        break;
    }
    
    return Icon(
      iconData,
      size: 12,
      color: iconColor,
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            Images.noData, // Utiliser une image existante ou en ajouter une nouvelle
            width: 150,
            height: 150,
          ),
          const SizedBox(height: 20),
          Text(
            'Aucun message',
            style: rubikMedium.copyWith(fontSize: 18),
          ),
          const SizedBox(height: 10),
          Text(
            'Commencez la conversation en envoyant un message',
            style: rubikRegular.copyWith(fontSize: 14, color: Colors.grey),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      color: Colors.white,
      child: Row(
        children: [
          // Bouton emoji
          IconButton(
            icon: Icon(
              _showEmojiPicker ? Icons.keyboard : Icons.emoji_emotions,
              color: ColorResources.getPrimaryColor(),
            ),
            onPressed: () {
              setState(() {
                _showEmojiPicker = !_showEmojiPicker;
                if (_showEmojiPicker) {
                  FocusScope.of(context).unfocus();
                } else {
                  _focusNode.requestFocus();
                }
              });
            },
          ),
          
          // Champ de saisie
          Expanded(
            child: TextField(
              controller: _messageController,
              focusNode: _focusNode,
              decoration: InputDecoration(
                hintText: 'Tapez un message...',
                hintStyle: rubikRegular.copyWith(color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey.shade100,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              ),
              minLines: 1,
              maxLines: 5,
            ),
          ),
          
          const SizedBox(width: 8),
          
          // Bouton d'envoi
          Obx(() {
            return _chatDetailController.isSending
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : IconButton(
                    icon: const Icon(Icons.send),
                    color: ColorResources.getPrimaryColor(),
                    onPressed: _sendMessage,
                  );
          }),
        ],
      ),
    );
  }

  Widget _buildEmojiPicker() {
    return SizedBox(
      height: 250,
      child: EmojiPicker(
        onEmojiSelected: (category, emoji) {
          // Si le champ de texte est vide, envoyer l'emoji directement
          if (_messageController.text.isEmpty) {
            _chatDetailController.sendEmoji(emoji.emoji);
          } else {
            // Sinon, ajouter l'emoji au texte
            _messageController.text += emoji.emoji;
          }
        },
        onBackspacePressed: () {
          _messageController
            ..text = _messageController.text.characters.skipLast(1).toString()
            ..selection = TextSelection.fromPosition(
                TextPosition(offset: _messageController.text.length));
        },
        config: Config(
          columns: 7,
          emojiSizeMax: 32 * (foundation.defaultTargetPlatform == TargetPlatform.iOS ? 1.30 : 1.0),
          verticalSpacing: 0,
          horizontalSpacing: 0,
          gridPadding: EdgeInsets.zero,
          initCategory: Category.RECENT,
          bgColor: const Color(0xFFF2F2F2),
          indicatorColor: ColorResources.getPrimaryColor(),
          iconColor: Colors.grey,
          iconColorSelected: ColorResources.getPrimaryColor(),
          backspaceColor: ColorResources.getPrimaryColor(),
          skinToneDialogBgColor: Colors.white,
          skinToneIndicatorColor: Colors.grey,
          enableSkinTones: true,
          showRecentsTab: true,
          recentsLimit: 28,
          noRecents: const Text(
            'Aucun emoji récent',
            style: TextStyle(fontSize: 20, color: Colors.black26),
            textAlign: TextAlign.center,
          ),
          loadingIndicator: const SizedBox.shrink(),
          tabIndicatorAnimDuration: kTabScrollDuration,
          categoryIcons: const CategoryIcons(),
          buttonMode: ButtonMode.MATERIAL,
        ),
      ),
    );
  }

  void _sendMessage() {
    if (_messageController.text.trim().isNotEmpty) {
      _chatDetailController.sendMessage(_messageController.text.trim());
      _messageController.clear();
    }
  }

  Widget _getSourceIcon(MessageSource source) {
    IconData iconData;
    Color iconColor;
    
    switch (source) {
      case MessageSource.sms:
        iconData = Icons.sms;
        iconColor = Colors.green;
        break;
      case MessageSource.rcs:
        iconData = Icons.chat;
        iconColor = Colors.blue;
        break;
      case MessageSource.online:
      default:
        iconData = Icons.cloud;
        iconColor = ColorResources.getPrimaryColor();
        break;
    }
    
    return Icon(
      iconData,
      size: 12,
      color: iconColor,
    );
  }

  String _formatTime(DateTime dateTime) {
    return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
}
