import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/home/screens/home_screen.dart';
import 'package:six_cash/features/chat/domain/services/sms_service.dart';
import 'package:six_cash/features/chat/domain/services/rcs_service.dart';
import 'package:six_cash/features/chat/domain/services/chat_storage_service.dart';
import 'package:six_cash/features/chat/domain/services/chat_sync_service.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';
import 'package:six_cash/services/connectivity_service.dart';

class ChatTestScreen extends StatefulWidget {
  const ChatTestScreen({Key? key}) : super(key: key);

  @override
  State<ChatTestScreen> createState() => _ChatTestScreenState();
}

class _ChatTestScreenState extends State<ChatTestScreen> {
  final SmsService _smsService = Get.find<SmsService>();
  final RcsService _rcsService = Get.find<RcsService>();
  final ChatStorageService _chatStorageService = Get.find<ChatStorageService>();
  final ChatSyncService _chatSyncService = Get.find<ChatSyncService>();
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  
  bool _isLoading = false;
  String _testResult = '';
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Test du Chat Hors Ligne'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.off(() => const HomeScreen()),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Cette page permet de tester les fonctionnalités du chat hors ligne',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            
            // Statut de connectivité
            Obx(() => Card(
              color: _connectivityService.isConnected ? Colors.green.shade100 : Colors.red.shade100,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(
                      _connectivityService.isConnected ? Icons.wifi : Icons.wifi_off,
                      color: _connectivityService.isConnected ? Colors.green : Colors.red,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _connectivityService.isConnected ? 'En ligne' : 'Hors ligne',
                      style: TextStyle(
                        color: _connectivityService.isConnected ? Colors.green : Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            )),
            
            const SizedBox(height: 20),
            
            // Tests SMS
            const Text('Tests SMS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _testSmsPermissions,
              child: const Text('Tester les permissions SMS'),
            ),
            ElevatedButton(
              onPressed: _testSmsSending,
              child: const Text('Simuler l\'envoi d\'un SMS'),
            ),
            ElevatedButton(
              onPressed: _testSmsReceiving,
              child: const Text('Simuler la réception d\'un SMS'),
            ),
            
            const SizedBox(height: 20),
            
            // Tests RCS
            const Text('Tests RCS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _testRcsAvailability,
              child: const Text('Tester la disponibilité RCS'),
            ),
            ElevatedButton(
              onPressed: _testRcsSending,
              child: const Text('Simuler l\'envoi d\'un message RCS'),
            ),
            ElevatedButton(
              onPressed: _testRcsEmoji,
              child: const Text('Simuler l\'envoi d\'un emoji RCS'),
            ),
            
            const SizedBox(height: 20),
            
            // Tests de synchronisation
            const Text('Tests de synchronisation', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _testSyncMessages,
              child: const Text('Tester la synchronisation des messages'),
            ),
            
            const SizedBox(height: 20),
            
            // Résultats des tests
            if (_isLoading)
              const Center(child: CircularProgressIndicator()),
            
            if (_testResult.isNotEmpty)
              Card(
                color: Colors.blue.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Résultat du test:', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(_testResult),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Future<void> _testSmsPermissions() async {
    setState(() {
      _isLoading = true;
      _testResult = '';
    });
    
    try {
      bool hasPermission = await _smsService.checkSmsPermissions();
      
      setState(() {
        _testResult = hasPermission 
            ? 'Permissions SMS accordées ✅' 
            : 'Permissions SMS refusées ❌\nVeuillez accorder les permissions dans les paramètres de l\'application.';
      });
    } catch (e) {
      setState(() {
        _testResult = 'Erreur lors du test des permissions SMS: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _testSmsSending() async {
    setState(() {
      _isLoading = true;
      _testResult = '';
    });
    
    try {
      // Simuler l'envoi d'un SMS
      String testPhoneNumber = '+33612345678';
      String testMessage = 'Ceci est un message de test SMS (${DateTime.now()})';
      
      // Dans un environnement de test, nous ne voulons pas réellement envoyer de SMS
      // Nous utilisons donc une méthode simulée
      
      // Créer le modèle de message
      String messageId = DateTime.now().millisecondsSinceEpoch.toString();
      ChatMessageModel chatMessage = ChatMessageModel(
        id: messageId,
        senderId: 'current_user',
        receiverId: testPhoneNumber,
        content: testMessage,
        timestamp: DateTime.now(),
        type: MessageType.text,
        status: MessageStatus.sent,
        source: MessageSource.sms,
        isRead: false,
      );
      
      // Stocker le message localement
      await _chatStorageService.saveMessage(chatMessage);
      
      setState(() {
        _testResult = 'SMS de test simulé avec succès ✅\n'
            'Destinataire: $testPhoneNumber\n'
            'Message: $testMessage\n'
            'Le message a été enregistré dans le stockage local.';
      });
    } catch (e) {
      setState(() {
        _testResult = 'Erreur lors de la simulation d\'envoi de SMS: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _testSmsReceiving() async {
    setState(() {
      _isLoading = true;
      _testResult = '';
    });
    
    try {
      // Simuler la réception d'un SMS
      String testSender = '+33687654321';
      String testMessage = 'Ceci est une réponse de test SMS (${DateTime.now()})';
      
      await _smsService.receiveSms(testSender, testMessage);
      
      setState(() {
        _testResult = 'Réception de SMS simulée avec succès ✅\n'
            'Expéditeur: $testSender\n'
            'Message: $testMessage\n'
            'Le message a été enregistré dans le stockage local.';
      });
    } catch (e) {
      setState(() {
        _testResult = 'Erreur lors de la simulation de réception de SMS: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _testRcsAvailability() async {
    setState(() {
      _isLoading = true;
      _testResult = '';
    });
    
    try {
      // Tester la disponibilité RCS pour quelques numéros
      String testPhoneNumber1 = '+33612345678';
      String testPhoneNumber2 = '+33687654321';
      
      bool isAvailable1 = await _rcsService.isRcsAvailable(testPhoneNumber1);
      bool isAvailable2 = await _rcsService.isRcsAvailable(testPhoneNumber2);
      
      setState(() {
        _testResult = 'Test de disponibilité RCS terminé ✅\n'
            'Numéro 1 ($testPhoneNumber1): ${isAvailable1 ? "RCS disponible" : "RCS non disponible"}\n'
            'Numéro 2 ($testPhoneNumber2): ${isAvailable2 ? "RCS disponible" : "RCS non disponible"}\n\n'
            'Note: Dans cette version de test, la disponibilité RCS est simulée.';
      });
    } catch (e) {
      setState(() {
        _testResult = 'Erreur lors du test de disponibilité RCS: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _testRcsSending() async {
    setState(() {
      _isLoading = true;
      _testResult = '';
    });
    
    try {
      // Simuler l'envoi d'un message RCS
      String testPhoneNumber = '+33612345678';
      String testMessage = 'Ceci est un message de test RCS (${DateTime.now()})';
      
      await _rcsService.sendRcsMessage(testPhoneNumber, testMessage);
      
      setState(() {
        _testResult = 'Message RCS de test simulé avec succès ✅\n'
            'Destinataire: $testPhoneNumber\n'
            'Message: $testMessage\n'
            'Le message a été enregistré dans le stockage local.';
      });
    } catch (e) {
      setState(() {
        _testResult = 'Erreur lors de la simulation d\'envoi de message RCS: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _testRcsEmoji() async {
    setState(() {
      _isLoading = true;
      _testResult = '';
    });
    
    try {
      // Simuler l'envoi d'un emoji via RCS
      String testPhoneNumber = '+33612345678';
      String testEmoji = '😀';
      
      await _rcsService.sendEmoji(testPhoneNumber, testEmoji);
      
      setState(() {
        _testResult = 'Emoji RCS de test simulé avec succès ✅\n'
            'Destinataire: $testPhoneNumber\n'
            'Emoji: $testEmoji\n'
            'Le message a été enregistré dans le stockage local.';
      });
    } catch (e) {
      setState(() {
        _testResult = 'Erreur lors de la simulation d\'envoi d\'emoji RCS: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _testSyncMessages() async {
    setState(() {
      _isLoading = true;
      _testResult = '';
    });
    
    try {
      bool syncResult = await _chatSyncService.syncMessages();
      
      setState(() {
        _testResult = syncResult 
            ? 'Synchronisation des messages réussie ✅\n'
                'Tous les messages ont été synchronisés avec le serveur (simulation).'
            : 'Échec de la synchronisation des messages ❌\n'
                'Raison: ${_chatSyncService.lastSyncError}\n'
                'Vérifiez votre connexion internet et réessayez.';
      });
    } catch (e) {
      setState(() {
        _testResult = 'Erreur lors de la synchronisation des messages: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
}
