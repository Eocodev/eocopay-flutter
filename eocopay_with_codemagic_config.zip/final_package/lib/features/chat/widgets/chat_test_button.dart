import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/helper/route_helper.dart';
import 'package:six_cash/features/chat/screens/chat_test_screen.dart';

class ChatTestButton extends StatelessWidget {
  const ChatTestButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: () {
        Get.to(() => const ChatTestScreen());
      },
      icon: const Icon(Icons.bug_report),
      label: const Text('Tester le chat hors ligne'),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.amber,
        foregroundColor: Colors.black,
      ),
    );
  }
}
