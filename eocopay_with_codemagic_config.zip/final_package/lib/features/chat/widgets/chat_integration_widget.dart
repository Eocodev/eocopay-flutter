import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/chat/screens/chat_list_screen.dart';
import 'package:six_cash/features/chat/controllers/chat_list_controller.dart';
import 'package:six_cash/common/widgets/network_aware_widget.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/util/color_resources.dart';
import 'package:six_cash/util/images.dart';

class ChatIntegrationWidget extends StatelessWidget {
  const ChatIntegrationWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Initialiser le contrôleur de liste de chat si nécessaire
    Get.lazyPut(() => ChatListController(), fenix: true);
    
    return NetworkAwareWidget(
      onlineChild: _buildChatButton(context, false),
      offlineChild: _buildChatButton(context, true),
    );
  }
  
  Widget _buildChatButton(BuildContext context, bool isOffline) {
    return InkWell(
      onTap: () {
        Get.to(() => const ChatListScreen());
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isOffline ? Colors.grey.shade200 : ColorResources.getPrimaryColor().withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isOffline ? Colors.grey : ColorResources.getPrimaryColor(),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.chat,
              color: isOffline ? Colors.grey.shade700 : ColorResources.getPrimaryColor(),
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              isOffline ? 'Messages (Hors ligne)' : 'Messages',
              style: rubikMedium.copyWith(
                fontSize: 14,
                color: isOffline ? Colors.grey.shade700 : ColorResources.getPrimaryColor(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
