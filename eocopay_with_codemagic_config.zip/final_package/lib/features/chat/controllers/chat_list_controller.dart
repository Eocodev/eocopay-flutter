import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/chat/domain/models/chat_conversation_model.dart';
import 'package:six_cash/features/chat/domain/services/chat_storage_service.dart';
import 'package:six_cash/services/connectivity_service.dart';

class ChatListController extends GetxController {
  final ChatStorageService _chatStorageService = Get.find<ChatStorageService>();
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  
  final RxList<ChatConversationModel> _conversations = <ChatConversationModel>[].obs;
  final RxBool _isLoading = false.obs;
  final RxBool _isOffline = false.obs;
  
  List<ChatConversationModel> get conversations => _conversations;
  bool get isLoading => _isLoading.value;
  bool get isOffline => _isOffline.value;
  
  @override
  void onInit() {
    super.onInit();
    _loadConversations();
    
    // S'abonner aux changements de connectivité
    _connectivityService.connectivityStream.listen((isConnected) {
      _isOffline.value = !isConnected;
      if (isConnected) {
        // Si la connexion est rétablie, synchroniser les conversations
        _syncConversations();
      }
    });
  }
  
  // Charger les conversations depuis le stockage local
  Future<void> _loadConversations() async {
    _isLoading.value = true;
    try {
      final conversations = await _chatStorageService.getConversations();
      _conversations.assignAll(conversations);
    } catch (e) {
      print('Erreur lors du chargement des conversations: $e');
    } finally {
      _isLoading.value = false;
    }
  }
  
  // Rafraîchir la liste des conversations
  Future<void> refreshConversations() async {
    await _loadConversations();
  }
  
  // Synchroniser les conversations avec le serveur (simulé)
  Future<void> _syncConversations() async {
    // Dans une implémentation réelle, nous synchroniserions avec le serveur
    // Pour l'instant, nous mettons simplement à jour l'heure de synchronisation
    await _chatStorageService.saveLastSyncTime();
  }
  
  // Marquer une conversation comme lue
  Future<void> markConversationAsRead(String conversationId) async {
    await _chatStorageService.markConversationAsRead(conversationId);
    await refreshConversations();
  }
  
  // Supprimer une conversation
  Future<void> deleteConversation(String conversationId) async {
    await _chatStorageService.deleteConversation(conversationId);
    await refreshConversations();
  }
  
  // Créer une nouvelle conversation
  Future<void> createNewConversation(String participantId, String participantName, {String? participantAvatar}) async {
    final conversation = ChatConversationModel(
      id: participantId,
      participantId: participantId,
      participantName: participantName,
      participantAvatar: participantAvatar,
      lastMessageTime: DateTime.now(),
      lastMessageContent: '',
    );
    
    await _chatStorageService.saveConversation(conversation);
    await refreshConversations();
  }
}
