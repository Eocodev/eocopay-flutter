import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';
import 'package:six_cash/features/chat/domain/services/chat_storage_service.dart';
import 'package:six_cash/features/chat/domain/services/sms_service.dart';
import 'package:six_cash/features/chat/domain/services/rcs_service.dart';
import 'package:six_cash/services/connectivity_service.dart';

class ChatDetailController extends GetxController {
  final ChatStorageService _chatStorageService = Get.find<ChatStorageService>();
  final SmsService _smsService = Get.find<SmsService>();
  final RcsService _rcsService = Get.find<RcsService>();
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  
  final RxList<ChatMessageModel> _messages = <ChatMessageModel>[].obs;
  final RxBool _isLoading = false.obs;
  final RxBool _isSending = false.obs;
  final RxBool _isOffline = false.obs;
  final RxString _conversationId = ''.obs;
  final RxString _participantName = ''.obs;
  final RxString _participantAvatar = ''.obs;
  final Rx<MessageSource> _currentMessageSource = MessageSource.online.obs;
  
  List<ChatMessageModel> get messages => _messages;
  bool get isLoading => _isLoading.value;
  bool get isSending => _isSending.value;
  bool get isOffline => _isOffline.value;
  String get conversationId => _conversationId.value;
  String get participantName => _participantName.value;
  String get participantAvatar => _participantAvatar.value;
  MessageSource get currentMessageSource => _currentMessageSource.value;
  
  @override
  void onInit() {
    super.onInit();
    
    // S'abonner aux changements de connectivité
    _connectivityService.connectivityStream.listen((isConnected) {
      _isOffline.value = !isConnected;
      _updateMessageSource();
    });
  }
  
  // Initialiser le contrôleur avec les données de la conversation
  void initConversation(String conversationId, String participantName, {String? participantAvatar}) {
    _conversationId.value = conversationId;
    _participantName.value = participantName;
    _participantAvatar.value = participantAvatar ?? '';
    
    _loadMessages();
    _markConversationAsRead();
    _updateMessageSource();
  }
  
  // Charger les messages depuis le stockage local
  Future<void> _loadMessages() async {
    _isLoading.value = true;
    try {
      final messages = await _chatStorageService.getMessages(_conversationId.value);
      _messages.assignAll(messages);
    } catch (e) {
      print('Erreur lors du chargement des messages: $e');
    } finally {
      _isLoading.value = false;
    }
  }
  
  // Rafraîchir les messages
  Future<void> refreshMessages() async {
    await _loadMessages();
  }
  
  // Marquer la conversation comme lue
  Future<void> _markConversationAsRead() async {
    await _chatStorageService.markConversationAsRead(_conversationId.value);
  }
  
  // Mettre à jour la source de message en fonction de la connectivité
  void _updateMessageSource() {
    if (_isOffline.value) {
      _currentMessageSource.value = MessageSource.sms;
    } else {
      // Vérifier si RCS est disponible, sinon utiliser SMS
      _rcsService.isRcsAvailable(_conversationId.value).then((isAvailable) {
        _currentMessageSource.value = isAvailable ? MessageSource.rcs : MessageSource.online;
      });
    }
  }
  
  // Envoyer un message
  Future<bool> sendMessage(String content, {MessageType type = MessageType.text, Map<String, dynamic>? metadata}) async {
    if (content.isEmpty) return false;
    
    _isSending.value = true;
    bool success = false;
    
    try {
      switch (_currentMessageSource.value) {
        case MessageSource.sms:
          success = await _smsService.sendSms(_conversationId.value, content);
          break;
        case MessageSource.rcs:
          success = await _rcsService.sendRcsMessage(_conversationId.value, content, type: type, metadata: metadata);
          break;
        case MessageSource.online:
          // Dans une implémentation réelle, nous enverrions le message au serveur
          // Pour l'instant, nous simulons un envoi réussi et stockons localement
          String messageId = DateTime.now().millisecondsSinceEpoch.toString();
          ChatMessageModel message = ChatMessageModel(
            id: messageId,
            senderId: 'current_user',
            receiverId: _conversationId.value,
            content: content,
            timestamp: DateTime.now(),
            type: type,
            status: MessageStatus.sent,
            source: MessageSource.online,
            metadata: metadata,
          );
          await _chatStorageService.saveMessage(message);
          success = true;
          break;
      }
      
      if (success) {
        await refreshMessages();
      }
    } catch (e) {
      print('Erreur lors de l\'envoi du message: $e');
      success = false;
    } finally {
      _isSending.value = false;
    }
    
    return success;
  }
  
  // Envoyer un emoji
  Future<bool> sendEmoji(String emoji) async {
    return sendMessage(emoji, type: MessageType.emoji, metadata: {'emojiOnly': true});
  }
  
  // Changer manuellement la source de message
  void changeMessageSource(MessageSource source) {
    _currentMessageSource.value = source;
  }
}
