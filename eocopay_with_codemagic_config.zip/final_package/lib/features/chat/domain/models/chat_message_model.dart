import 'package:flutter/material.dart';

enum MessageType {
  text,
  image,
  emoji,
  location,
  file,
  audio,
  video,
}

enum MessageStatus {
  sending,
  sent,
  delivered,
  read,
  failed,
}

enum MessageSource {
  online,
  sms,
  rcs,
}

class ChatMessageModel {
  final String id;
  final String senderId;
  final String receiverId;
  final String content;
  final DateTime timestamp;
  final MessageType type;
  final MessageStatus status;
  final MessageSource source;
  final bool isRead;
  final Map<String, dynamic>? metadata;

  ChatMessageModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.content,
    required this.timestamp,
    this.type = MessageType.text,
    this.status = MessageStatus.sending,
    this.source = MessageSource.online,
    this.isRead = false,
    this.metadata,
  });

  // Créer un message à partir d'un Map (pour le stockage local)
  factory ChatMessageModel.fromJson(Map<String, dynamic> json) {
    return ChatMessageModel(
      id: json['id'],
      senderId: json['senderId'],
      receiverId: json['receiverId'],
      content: json['content'],
      timestamp: DateTime.parse(json['timestamp']),
      type: MessageType.values[json['type'] ?? 0],
      status: MessageStatus.values[json['status'] ?? 0],
      source: MessageSource.values[json['source'] ?? 0],
      isRead: json['isRead'] ?? false,
      metadata: json['metadata'],
    );
  }

  // Convertir le message en Map (pour le stockage local)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'senderId': senderId,
      'receiverId': receiverId,
      'content': content,
      'timestamp': timestamp.toIso8601String(),
      'type': type.index,
      'status': status.index,
      'source': source.index,
      'isRead': isRead,
      'metadata': metadata,
    };
  }

  // Créer une copie du message avec des modifications
  ChatMessageModel copyWith({
    String? id,
    String? senderId,
    String? receiverId,
    String? content,
    DateTime? timestamp,
    MessageType? type,
    MessageStatus? status,
    MessageSource? source,
    bool? isRead,
    Map<String, dynamic>? metadata,
  }) {
    return ChatMessageModel(
      id: id ?? this.id,
      senderId: senderId ?? this.senderId,
      receiverId: receiverId ?? this.receiverId,
      content: content ?? this.content,
      timestamp: timestamp ?? this.timestamp,
      type: type ?? this.type,
      status: status ?? this.status,
      source: source ?? this.source,
      isRead: isRead ?? this.isRead,
      metadata: metadata ?? this.metadata,
    );
  }
}
