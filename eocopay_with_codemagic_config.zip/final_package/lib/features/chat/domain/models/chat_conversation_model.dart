import 'package:flutter/material.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';

class ChatConversationModel {
  final String id;
  final String participantId;
  final String participantName;
  final String? participantAvatar;
  final DateTime lastMessageTime;
  final String lastMessageContent;
  final bool hasUnreadMessages;
  final int unreadCount;
  final MessageSource preferredSource;

  ChatConversationModel({
    required this.id,
    required this.participantId,
    required this.participantName,
    this.participantAvatar,
    required this.lastMessageTime,
    required this.lastMessageContent,
    this.hasUnreadMessages = false,
    this.unreadCount = 0,
    this.preferredSource = MessageSource.online,
  });

  // Créer une conversation à partir d'un Map (pour le stockage local)
  factory ChatConversationModel.fromJson(Map<String, dynamic> json) {
    return ChatConversationModel(
      id: json['id'],
      participantId: json['participantId'],
      participantName: json['participantName'],
      participantAvatar: json['participantAvatar'],
      lastMessageTime: DateTime.parse(json['lastMessageTime']),
      lastMessageContent: json['lastMessageContent'],
      hasUnreadMessages: json['hasUnreadMessages'] ?? false,
      unreadCount: json['unreadCount'] ?? 0,
      preferredSource: MessageSource.values[json['preferredSource'] ?? 0],
    );
  }

  // Convertir la conversation en Map (pour le stockage local)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'participantId': participantId,
      'participantName': participantName,
      'participantAvatar': participantAvatar,
      'lastMessageTime': lastMessageTime.toIso8601String(),
      'lastMessageContent': lastMessageContent,
      'hasUnreadMessages': hasUnreadMessages,
      'unreadCount': unreadCount,
      'preferredSource': preferredSource.index,
    };
  }

  // Créer une copie de la conversation avec des modifications
  ChatConversationModel copyWith({
    String? id,
    String? participantId,
    String? participantName,
    String? participantAvatar,
    DateTime? lastMessageTime,
    String? lastMessageContent,
    bool? hasUnreadMessages,
    int? unreadCount,
    MessageSource? preferredSource,
  }) {
    return ChatConversationModel(
      id: id ?? this.id,
      participantId: participantId ?? this.participantId,
      participantName: participantName ?? this.participantName,
      participantAvatar: participantAvatar ?? this.participantAvatar,
      lastMessageTime: lastMessageTime ?? this.lastMessageTime,
      lastMessageContent: lastMessageContent ?? this.lastMessageContent,
      hasUnreadMessages: hasUnreadMessages ?? this.hasUnreadMessages,
      unreadCount: unreadCount ?? this.unreadCount,
      preferredSource: preferredSource ?? this.preferredSource,
    );
  }
}
