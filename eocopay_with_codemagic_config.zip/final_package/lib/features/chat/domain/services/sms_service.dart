import 'package:flutter/material.dart';
import 'package:flutter_sms/flutter_sms.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';
import 'package:six_cash/features/chat/domain/models/chat_conversation_model.dart';
import 'package:six_cash/features/chat/domain/services/chat_storage_service.dart';
import 'package:six_cash/services/connectivity_service.dart';

class SmsService extends GetxService {
  final ChatStorageService _chatStorageService = Get.find<ChatStorageService>();
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  
  // Méthode pour vérifier et demander les permissions SMS
  Future<bool> checkSmsPermissions() async {
    var status = await Permission.sms.status;
    
    if (status.isDenied) {
      status = await Permission.sms.request();
    }
    
    return status.isGranted;
  }
  
  // Méthode pour envoyer un SMS
  Future<bool> sendSms(String phoneNumber, String message) async {
    try {
      // Vérifier les permissions
      bool hasPermission = await checkSmsPermissions();
      if (!hasPermission) {
        throw Exception("Permission SMS refusée");
      }
      
      // Envoyer le SMS via la bibliothèque flutter_sms
      String result = await sendSMS(
        message: message,
        recipients: [phoneNumber],
        sendDirect: true,
      );
      
      bool success = result.contains("sent") || result.contains("success");
      
      // Générer un ID unique pour le message
      String messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
      // Créer le modèle de message
      ChatMessageModel chatMessage = ChatMessageModel(
        id: messageId,
        senderId: 'current_user', // L'utilisateur actuel est l'expéditeur
        receiverId: phoneNumber,
        content: message,
        timestamp: DateTime.now(),
        type: MessageType.text,
        status: success ? MessageStatus.sent : MessageStatus.failed,
        source: MessageSource.sms,
        isRead: false,
      );
      
      // Stocker le message localement
      await _chatStorageService.saveMessage(chatMessage);
      
      // Créer ou mettre à jour la conversation
      ChatConversationModel conversation = ChatConversationModel(
        id: phoneNumber,
        participantId: phoneNumber,
        participantName: phoneNumber, // Utiliser le numéro comme nom par défaut
        lastMessageTime: DateTime.now(),
        lastMessageContent: message,
        preferredSource: MessageSource.sms,
      );
      
      await _chatStorageService.saveConversation(conversation);
      
      return success;
    } catch (e) {
      print('Erreur lors de l\'envoi du SMS: $e');
      
      // Enregistrer le message comme échoué
      String messageId = DateTime.now().millisecondsSinceEpoch.toString();
      ChatMessageModel chatMessage = ChatMessageModel(
        id: messageId,
        senderId: 'current_user',
        receiverId: phoneNumber,
        content: message,
        timestamp: DateTime.now(),
        type: MessageType.text,
        status: MessageStatus.failed,
        source: MessageSource.sms,
        isRead: false,
      );
      
      await _chatStorageService.saveMessage(chatMessage);
      
      return false;
    }
  }
  
  // Méthode pour configurer un écouteur de SMS entrants
  Future<void> setupSmsListener() async {
    // Cette fonctionnalité nécessiterait un plugin spécifique pour intercepter les SMS
    // comme flutter_sms_inbox ou telephony
    // Pour l'instant, nous simulons cette fonctionnalité
    
    print('Configuration de l\'écouteur de SMS (simulation)');
    
    // Dans une implémentation réelle, nous utiliserions quelque chose comme:
    // telephony.listenIncomingSms(
    //   onNewMessage: (SmsMessage message) {
    //     receiveSms(message.address, message.body);
    //   },
    //   listenInBackground: false,
    // );
  }
  
  // Méthode pour recevoir un SMS (appelée par l'écouteur ou simulée)
  Future<void> receiveSms(String senderPhoneNumber, String message) async {
    try {
      // Générer un ID unique pour le message
      String messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
      // Créer le modèle de message
      ChatMessageModel chatMessage = ChatMessageModel(
        id: messageId,
        senderId: senderPhoneNumber, // L'expéditeur est l'autre personne
        receiverId: 'current_user', // L'utilisateur actuel est le destinataire
        content: message,
        timestamp: DateTime.now(),
        type: MessageType.text,
        status: MessageStatus.delivered,
        source: MessageSource.sms,
        isRead: false,
      );
      
      // Stocker le message localement
      await _chatStorageService.saveMessage(chatMessage);
      
      // Créer ou mettre à jour la conversation
      ChatConversationModel conversation = ChatConversationModel(
        id: senderPhoneNumber,
        participantId: senderPhoneNumber,
        participantName: senderPhoneNumber, // Utiliser le numéro comme nom par défaut
        lastMessageTime: DateTime.now(),
        lastMessageContent: message,
        hasUnreadMessages: true,
        unreadCount: 1,
        preferredSource: MessageSource.sms,
      );
      
      await _chatStorageService.saveConversation(conversation);
      
      // Afficher une notification (dans une implémentation réelle)
      // NotificationHelper.showNotification(
      //   title: senderPhoneNumber,
      //   body: message,
      // );
    } catch (e) {
      print('Erreur lors de la réception du SMS: $e');
    }
  }
  
  // Méthode pour déterminer si le SMS doit être utilisé (en mode hors ligne)
  Future<bool> shouldUseSms() async {
    return !_connectivityService.isConnected;
  }
  
  // Méthode pour simuler la réception d'un SMS (pour les tests)
  Future<void> simulateIncomingSms(String senderPhoneNumber, String message) async {
    await receiveSms(senderPhoneNumber, message);
  }
}
