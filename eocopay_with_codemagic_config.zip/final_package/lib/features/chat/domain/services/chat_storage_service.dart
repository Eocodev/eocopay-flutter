import 'dart:convert';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';
import 'package:six_cash/features/chat/domain/models/chat_conversation_model.dart';

class ChatStorageService extends GetxService {
  final SharedPreferences sharedPreferences;
  final FlutterSecureStorage secureStorage = const FlutterSecureStorage();
  
  ChatStorageService({required this.sharedPreferences});
  
  // Clés pour le stockage
  static const String _conversationsKey = 'chat_conversations';
  static const String _messagesKeyPrefix = 'chat_messages_';
  static const String _lastSyncTimeKey = 'chat_last_sync_time';
  
  // Stocker une conversation
  Future<void> saveConversation(ChatConversationModel conversation) async {
    try {
      // Récupérer les conversations existantes
      List<ChatConversationModel> conversations = await getConversations();
      
      // Trouver l'index de la conversation si elle existe déjà
      int existingIndex = conversations.indexWhere((c) => c.id == conversation.id);
      
      if (existingIndex >= 0) {
        // Mettre à jour la conversation existante
        conversations[existingIndex] = conversation;
      } else {
        // Ajouter la nouvelle conversation
        conversations.add(conversation);
      }
      
      // Trier les conversations par date du dernier message (plus récent en premier)
      conversations.sort((a, b) => b.lastMessageTime.compareTo(a.lastMessageTime));
      
      // Convertir la liste en JSON et sauvegarder
      List<String> jsonList = conversations.map((conv) => jsonEncode(conv.toJson())).toList();
      await sharedPreferences.setStringList(_conversationsKey, jsonList);
      
    } catch (e) {
      print('Erreur lors de la sauvegarde de la conversation: $e');
    }
  }
  
  // Récupérer toutes les conversations
  Future<List<ChatConversationModel>> getConversations() async {
    try {
      List<String>? jsonList = sharedPreferences.getStringList(_conversationsKey);
      
      if (jsonList == null || jsonList.isEmpty) {
        return [];
      }
      
      return jsonList.map((jsonString) {
        Map<String, dynamic> map = jsonDecode(jsonString);
        return ChatConversationModel.fromJson(map);
      }).toList();
    } catch (e) {
      print('Erreur lors de la récupération des conversations: $e');
      return [];
    }
  }
  
  // Supprimer une conversation
  Future<void> deleteConversation(String conversationId) async {
    try {
      // Récupérer les conversations existantes
      List<ChatConversationModel> conversations = await getConversations();
      
      // Filtrer la conversation à supprimer
      conversations.removeWhere((conv) => conv.id == conversationId);
      
      // Convertir la liste en JSON et sauvegarder
      List<String> jsonList = conversations.map((conv) => jsonEncode(conv.toJson())).toList();
      await sharedPreferences.setStringList(_conversationsKey, jsonList);
      
      // Supprimer également les messages de cette conversation
      await sharedPreferences.remove('$_messagesKeyPrefix$conversationId');
      
    } catch (e) {
      print('Erreur lors de la suppression de la conversation: $e');
    }
  }
  
  // Stocker un message
  Future<void> saveMessage(ChatMessageModel message) async {
    try {
      String conversationId = message.senderId == 'current_user' 
          ? message.receiverId 
          : message.senderId;
      
      // Récupérer les messages existants pour cette conversation
      List<ChatMessageModel> messages = await getMessages(conversationId);
      
      // Vérifier si ce message existe déjà
      int existingIndex = messages.indexWhere((m) => m.id == message.id);
      
      if (existingIndex >= 0) {
        // Mettre à jour le message existant
        messages[existingIndex] = message;
      } else {
        // Ajouter le nouveau message
        messages.add(message);
      }
      
      // Trier les messages par date (plus ancien en premier)
      messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
      
      // Convertir la liste en JSON et sauvegarder
      List<String> jsonList = messages.map((msg) => jsonEncode(msg.toJson())).toList();
      await sharedPreferences.setStringList('$_messagesKeyPrefix$conversationId', jsonList);
      
      // Mettre à jour la conversation avec le dernier message
      await _updateConversationWithLastMessage(conversationId, message);
      
    } catch (e) {
      print('Erreur lors de la sauvegarde du message: $e');
    }
  }
  
  // Récupérer tous les messages d'une conversation
  Future<List<ChatMessageModel>> getMessages(String conversationId) async {
    try {
      List<String>? jsonList = sharedPreferences.getStringList('$_messagesKeyPrefix$conversationId');
      
      if (jsonList == null || jsonList.isEmpty) {
        return [];
      }
      
      return jsonList.map((jsonString) {
        Map<String, dynamic> map = jsonDecode(jsonString);
        return ChatMessageModel.fromJson(map);
      }).toList();
    } catch (e) {
      print('Erreur lors de la récupération des messages: $e');
      return [];
    }
  }
  
  // Mettre à jour une conversation avec le dernier message
  Future<void> _updateConversationWithLastMessage(String conversationId, ChatMessageModel message) async {
    try {
      List<ChatConversationModel> conversations = await getConversations();
      int index = conversations.indexWhere((conv) => conv.id == conversationId);
      
      if (index >= 0) {
        ChatConversationModel conversation = conversations[index];
        
        // Déterminer si le message est entrant (non lu)
        bool isIncoming = message.senderId != 'current_user';
        int newUnreadCount = isIncoming 
            ? conversation.unreadCount + 1 
            : conversation.unreadCount;
        
        // Mettre à jour la conversation
        ChatConversationModel updatedConversation = conversation.copyWith(
          lastMessageTime: message.timestamp,
          lastMessageContent: message.content,
          hasUnreadMessages: isIncoming ? true : conversation.hasUnreadMessages,
          unreadCount: newUnreadCount,
        );
        
        conversations[index] = updatedConversation;
        
        // Trier les conversations par date du dernier message (plus récent en premier)
        conversations.sort((a, b) => b.lastMessageTime.compareTo(a.lastMessageTime));
        
        // Sauvegarder les conversations mises à jour
        List<String> jsonList = conversations.map((conv) => jsonEncode(conv.toJson())).toList();
        await sharedPreferences.setStringList(_conversationsKey, jsonList);
      }
    } catch (e) {
      print('Erreur lors de la mise à jour de la conversation: $e');
    }
  }
  
  // Marquer tous les messages d'une conversation comme lus
  Future<void> markConversationAsRead(String conversationId) async {
    try {
      // Mettre à jour les messages
      List<ChatMessageModel> messages = await getMessages(conversationId);
      bool hasChanges = false;
      
      for (int i = 0; i < messages.length; i++) {
        if (!messages[i].isRead && messages[i].senderId != 'current_user') {
          messages[i] = messages[i].copyWith(isRead: true);
          hasChanges = true;
        }
      }
      
      if (hasChanges) {
        // Sauvegarder les messages mis à jour
        List<String> jsonList = messages.map((msg) => jsonEncode(msg.toJson())).toList();
        await sharedPreferences.setStringList('$_messagesKeyPrefix$conversationId', jsonList);
      }
      
      // Mettre à jour la conversation
      List<ChatConversationModel> conversations = await getConversations();
      int index = conversations.indexWhere((conv) => conv.id == conversationId);
      
      if (index >= 0) {
        ChatConversationModel updatedConversation = conversations[index].copyWith(
          hasUnreadMessages: false,
          unreadCount: 0,
        );
        
        conversations[index] = updatedConversation;
        
        // Sauvegarder les conversations mises à jour
        List<String> jsonList = conversations.map((conv) => jsonEncode(conv.toJson())).toList();
        await sharedPreferences.setStringList(_conversationsKey, jsonList);
      }
    } catch (e) {
      print('Erreur lors du marquage de la conversation comme lue: $e');
    }
  }
  
  // Enregistrer l'heure de la dernière synchronisation
  Future<void> saveLastSyncTime() async {
    await sharedPreferences.setString(_lastSyncTimeKey, DateTime.now().toIso8601String());
  }
  
  // Récupérer l'heure de la dernière synchronisation
  Future<DateTime?> getLastSyncTime() async {
    String? lastSyncTimeStr = sharedPreferences.getString(_lastSyncTimeKey);
    
    if (lastSyncTimeStr == null) {
      return null;
    }
    
    return DateTime.parse(lastSyncTimeStr);
  }
  
  // Vérifier si une synchronisation est nécessaire
  Future<bool> isSyncRequired() async {
    DateTime? lastSyncTime = await getLastSyncTime();
    
    if (lastSyncTime == null) {
      return true;
    }
    
    DateTime now = DateTime.now();
    
    // Synchroniser si la dernière synchronisation date de plus de 1 heure
    return now.difference(lastSyncTime).inHours > 1;
  }
}
