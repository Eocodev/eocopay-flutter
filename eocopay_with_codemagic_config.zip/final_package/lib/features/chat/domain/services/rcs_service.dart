import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';
import 'package:six_cash/features/chat/domain/models/chat_conversation_model.dart';
import 'package:six_cash/features/chat/domain/services/chat_storage_service.dart';
import 'package:six_cash/services/connectivity_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RcsService extends GetxService {
  final ChatStorageService _chatStorageService = Get.find<ChatStorageService>();
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  
  // URL de base pour l'API RCS (simulée)
  final String _baseUrl = 'https://api.rcs-platform.com/v1';
  
  // Méthode pour vérifier si RCS est disponible pour un numéro
  Future<bool> isRcsAvailable(String phoneNumber) async {
    try {
      // Dans une implémentation réelle, nous ferions une requête à l'API RCS
      // Pour l'instant, nous simulons la disponibilité en fonction de la connectivité
      if (!_connectivityService.isConnected) {
        return false;
      }
      
      // Simuler une vérification de capacité RCS
      // Dans une implémentation réelle, nous utiliserions quelque chose comme:
      // final response = await http.get(Uri.parse('$_baseUrl/capability?msisdn=$phoneNumber'));
      // return response.statusCode == 200 && jsonDecode(response.body)['rcs_available'] == true;
      
      // Pour l'instant, nous supposons que 80% des numéros prennent en charge RCS
      return phoneNumber.hashCode % 10 < 8;
    } catch (e) {
      print('Erreur lors de la vérification de la disponibilité RCS: $e');
      return false;
    }
  }
  
  // Méthode pour envoyer un message RCS
  Future<bool> sendRcsMessage(String phoneNumber, String message, {MessageType type = MessageType.text, Map<String, dynamic>? metadata}) async {
    try {
      if (!_connectivityService.isConnected) {
        throw Exception("Pas de connexion Internet");
      }
      
      // Vérifier si RCS est disponible pour ce numéro
      bool rcsAvailable = await isRcsAvailable(phoneNumber);
      if (!rcsAvailable) {
        throw Exception("RCS non disponible pour ce numéro");
      }
      
      // Dans une implémentation réelle, nous enverrions le message via l'API RCS
      // Exemple:
      // final response = await http.post(
      //   Uri.parse('$_baseUrl/messages'),
      //   headers: {'Content-Type': 'application/json'},
      //   body: jsonEncode({
      //     'recipient': phoneNumber,
      //     'content': message,
      //     'type': type.toString(),
      //     'metadata': metadata,
      //   }),
      // );
      // bool success = response.statusCode == 200;
      
      // Pour l'instant, nous simulons un envoi réussi
      bool success = true;
      
      // Générer un ID unique pour le message
      String messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
      // Créer le modèle de message
      ChatMessageModel chatMessage = ChatMessageModel(
        id: messageId,
        senderId: 'current_user', // L'utilisateur actuel est l'expéditeur
        receiverId: phoneNumber,
        content: message,
        timestamp: DateTime.now(),
        type: type,
        status: success ? MessageStatus.sent : MessageStatus.failed,
        source: MessageSource.rcs,
        isRead: false,
        metadata: metadata,
      );
      
      // Stocker le message localement
      await _chatStorageService.saveMessage(chatMessage);
      
      // Créer ou mettre à jour la conversation
      ChatConversationModel conversation = ChatConversationModel(
        id: phoneNumber,
        participantId: phoneNumber,
        participantName: phoneNumber, // Utiliser le numéro comme nom par défaut
        lastMessageTime: DateTime.now(),
        lastMessageContent: message,
        preferredSource: MessageSource.rcs,
      );
      
      await _chatStorageService.saveConversation(conversation);
      
      // Simuler un délai pour la livraison et la lecture
      _simulateMessageDeliveryAndRead(messageId, phoneNumber);
      
      return success;
    } catch (e) {
      print('Erreur lors de l\'envoi du message RCS: $e');
      
      // Enregistrer le message comme échoué
      String messageId = DateTime.now().millisecondsSinceEpoch.toString();
      ChatMessageModel chatMessage = ChatMessageModel(
        id: messageId,
        senderId: 'current_user',
        receiverId: phoneNumber,
        content: message,
        timestamp: DateTime.now(),
        type: type,
        status: MessageStatus.failed,
        source: MessageSource.rcs,
        isRead: false,
        metadata: metadata,
      );
      
      await _chatStorageService.saveMessage(chatMessage);
      
      return false;
    }
  }
  
  // Méthode pour simuler la livraison et la lecture d'un message
  Future<void> _simulateMessageDeliveryAndRead(String messageId, String phoneNumber) async {
    // Simuler la livraison après 1 seconde
    await Future.delayed(const Duration(seconds: 1));
    
    try {
      // Récupérer les messages de cette conversation
      List<ChatMessageModel> messages = await _chatStorageService.getMessages(phoneNumber);
      
      // Trouver le message
      int index = messages.indexWhere((m) => m.id == messageId);
      if (index >= 0) {
        // Mettre à jour le statut du message à "livré"
        ChatMessageModel updatedMessage = messages[index].copyWith(
          status: MessageStatus.delivered,
        );
        
        await _chatStorageService.saveMessage(updatedMessage);
        
        // Simuler la lecture après 3 secondes supplémentaires
        await Future.delayed(const Duration(seconds: 3));
        
        // Mettre à jour le statut du message à "lu"
        updatedMessage = updatedMessage.copyWith(
          status: MessageStatus.read,
        );
        
        await _chatStorageService.saveMessage(updatedMessage);
      }
    } catch (e) {
      print('Erreur lors de la simulation de livraison/lecture: $e');
    }
  }
  
  // Méthode pour recevoir un message RCS (simulée)
  Future<void> receiveRcsMessage(String senderPhoneNumber, String message, {MessageType type = MessageType.text, Map<String, dynamic>? metadata}) async {
    try {
      // Générer un ID unique pour le message
      String messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
      // Créer le modèle de message
      ChatMessageModel chatMessage = ChatMessageModel(
        id: messageId,
        senderId: senderPhoneNumber, // L'expéditeur est l'autre personne
        receiverId: 'current_user', // L'utilisateur actuel est le destinataire
        content: message,
        timestamp: DateTime.now(),
        type: type,
        status: MessageStatus.delivered,
        source: MessageSource.rcs,
        isRead: false,
        metadata: metadata,
      );
      
      // Stocker le message localement
      await _chatStorageService.saveMessage(chatMessage);
      
      // Créer ou mettre à jour la conversation
      ChatConversationModel conversation = ChatConversationModel(
        id: senderPhoneNumber,
        participantId: senderPhoneNumber,
        participantName: senderPhoneNumber, // Utiliser le numéro comme nom par défaut
        lastMessageTime: DateTime.now(),
        lastMessageContent: message,
        hasUnreadMessages: true,
        unreadCount: 1,
        preferredSource: MessageSource.rcs,
      );
      
      await _chatStorageService.saveConversation(conversation);
      
      // Afficher une notification (dans une implémentation réelle)
      // NotificationHelper.showNotification(
      //   title: senderPhoneNumber,
      //   body: message,
      // );
    } catch (e) {
      print('Erreur lors de la réception du message RCS: $e');
    }
  }
  
  // Méthode pour envoyer un emoji via RCS
  Future<bool> sendEmoji(String phoneNumber, String emoji) async {
    return sendRcsMessage(
      phoneNumber, 
      emoji, 
      type: MessageType.emoji,
      metadata: {'emojiOnly': true}
    );
  }
  
  // Méthode pour simuler la réception d'un message RCS (pour les tests)
  Future<void> simulateIncomingRcsMessage(String senderPhoneNumber, String message, {MessageType type = MessageType.text, Map<String, dynamic>? metadata}) async {
    await receiveRcsMessage(senderPhoneNumber, message, type: type, metadata: metadata);
  }
}
