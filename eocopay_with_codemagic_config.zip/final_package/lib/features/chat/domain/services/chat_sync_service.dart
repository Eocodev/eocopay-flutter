import 'package:get/get.dart';
import 'package:six_cash/features/chat/domain/models/chat_message_model.dart';
import 'package:six_cash/features/chat/domain/services/chat_storage_service.dart';
import 'package:six_cash/services/connectivity_service.dart';

class ChatSyncService extends GetxService {
  final ChatStorageService _chatStorageService = Get.find<ChatStorageService>();
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  
  final RxBool _isSyncing = false.obs;
  final RxBool _lastSyncFailed = false.obs;
  final RxString _lastSyncError = ''.obs;
  
  bool get isSyncing => _isSyncing.value;
  bool get lastSyncFailed => _lastSyncFailed.value;
  String get lastSyncError => _lastSyncError.value;
  
  // Initialiser le service de synchronisation
  @override
  void onInit() {
    super.onInit();
    
    // S'abonner aux changements de connectivité
    _connectivityService.connectivityStream.listen((isConnected) {
      if (isConnected) {
        // Lancer une synchronisation lorsque la connexion est rétablie
        syncMessages();
      }
    });
  }
  
  // Synchroniser les messages avec le serveur
  Future<bool> syncMessages() async {
    if (_isSyncing.value) {
      return false; // Éviter les synchronisations simultanées
    }
    
    if (!_connectivityService.isConnected) {
      _lastSyncFailed.value = true;
      _lastSyncError.value = 'Pas de connexion Internet';
      return false;
    }
    
    _isSyncing.value = true;
    _lastSyncFailed.value = false;
    _lastSyncError.value = '';
    
    try {
      // 1. Récupérer tous les messages non synchronisés
      List<ChatMessageModel> pendingMessages = await _getPendingMessages();
      
      if (pendingMessages.isEmpty) {
        // Aucun message à synchroniser
        await _chatStorageService.saveLastSyncTime();
        _isSyncing.value = false;
        return true;
      }
      
      // 2. Envoyer les messages au serveur (simulé)
      bool success = await _sendPendingMessagesToServer(pendingMessages);
      
      if (success) {
        // 3. Mettre à jour les statuts des messages
        await _updateSyncedMessageStatus(pendingMessages);
        
        // 4. Enregistrer l'heure de la dernière synchronisation
        await _chatStorageService.saveLastSyncTime();
      } else {
        _lastSyncFailed.value = true;
        _lastSyncError.value = 'Échec de la synchronisation avec le serveur';
      }
      
      _isSyncing.value = false;
      return success;
    } catch (e) {
      print('Erreur lors de la synchronisation des messages: $e');
      _lastSyncFailed.value = true;
      _lastSyncError.value = e.toString();
      _isSyncing.value = false;
      return false;
    }
  }
  
  // Récupérer les messages qui doivent être synchronisés
  Future<List<ChatMessageModel>> _getPendingMessages() async {
    List<ChatMessageModel> pendingMessages = [];
    
    // Récupérer toutes les conversations
    final conversations = await _chatStorageService.getConversations();
    
    // Pour chaque conversation, récupérer les messages
    for (final conversation in conversations) {
      final messages = await _chatStorageService.getMessages(conversation.id);
      
      // Filtrer les messages qui doivent être synchronisés
      // (messages SMS ou messages non synchronisés)
      final messagesToSync = messages.where((message) => 
        (message.source == MessageSource.sms || message.source == MessageSource.rcs) && 
        message.senderId == 'current_user'
      ).toList();
      
      pendingMessages.addAll(messagesToSync);
    }
    
    return pendingMessages;
  }
  
  // Envoyer les messages en attente au serveur (simulé)
  Future<bool> _sendPendingMessagesToServer(List<ChatMessageModel> messages) async {
    // Dans une implémentation réelle, nous enverrions les messages au serveur
    // Pour l'instant, nous simulons un envoi réussi
    
    // Simuler un délai de réseau
    await Future.delayed(const Duration(seconds: 1));
    
    // Simuler une réussite à 95%
    return DateTime.now().millisecondsSinceEpoch % 20 != 0;
  }
  
  // Mettre à jour le statut des messages synchronisés
  Future<void> _updateSyncedMessageStatus(List<ChatMessageModel> messages) async {
    for (final message in messages) {
      // Créer une copie du message avec le statut mis à jour
      final updatedMessage = message.copyWith(
        source: MessageSource.online, // Marquer comme synchronisé en ligne
        status: MessageStatus.sent,
      );
      
      // Sauvegarder le message mis à jour
      await _chatStorageService.saveMessage(updatedMessage);
    }
  }
  
  // Vérifier si une synchronisation est nécessaire
  Future<bool> isSyncRequired() async {
    return await _chatStorageService.isSyncRequired();
  }
  
  // Forcer une synchronisation manuelle
  Future<bool> forceSyncMessages() async {
    return syncMessages();
  }
}
