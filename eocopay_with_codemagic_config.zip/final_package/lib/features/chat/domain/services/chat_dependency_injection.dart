import 'package:get/get.dart';
import 'package:six_cash/features/chat/domain/services/chat_storage_service.dart';
import 'package:six_cash/features/chat/domain/services/sms_service.dart';
import 'package:six_cash/features/chat/domain/services/rcs_service.dart';
import 'package:six_cash/features/chat/domain/services/chat_sync_service.dart';
import 'package:six_cash/features/chat/domain/services/sms_receiver.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChatDependencyInjection {
  static Future<void> init() async {
    // Obtenir l'instance de SharedPreferences
    final sharedPreferences = Get.find<SharedPreferences>();
    
    // Enregistrer les services de chat
    Get.lazyPut(() => ChatStorageService(sharedPreferences: sharedPreferences), fenix: true);
    Get.lazyPut(() => SmsService(), fenix: true);
    Get.lazyPut(() => RcsService(), fenix: true);
    Get.lazyPut(() => ChatSyncService(), fenix: true);
    Get.lazyPut(() => SmsReceiver(), fenix: true);
    
    // Initialiser le récepteur de SMS
    final smsReceiver = Get.find<SmsReceiver>();
    await smsReceiver.init();
  }
}
