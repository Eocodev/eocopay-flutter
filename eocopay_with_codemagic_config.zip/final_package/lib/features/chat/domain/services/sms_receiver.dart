import 'package:flutter/material.dart';
import 'package:telephony/telephony.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:six_cash/features/chat/domain/services/sms_service.dart';

class SmsReceiver extends GetxService {
  final SmsService _smsService = Get.find<SmsService>();
  final Telephony telephony = Telephony.instance;
  
  // Initialiser le récepteur de SMS
  Future<void> init() async {
    // Vérifier et demander les permissions
    bool permissionsGranted = await _checkPermissions();
    if (!permissionsGranted) {
      print('Permissions SMS non accordées');
      return;
    }
    
    // Configurer l'écouteur de SMS entrants
    telephony.listenIncomingSms(
      onNewMessage: _onNewSms,
      listenInBackground: false,
    );
    
    print('Récepteur de SMS initialisé avec succès');
  }
  
  // Vérifier et demander les permissions nécessaires
  Future<bool> _checkPermissions() async {
    var smsStatus = await Permission.sms.status;
    var phoneStatus = await Permission.phone.status;
    
    if (smsStatus.isDenied) {
      smsStatus = await Permission.sms.request();
    }
    
    if (phoneStatus.isDenied) {
      phoneStatus = await Permission.phone.request();
    }
    
    return smsStatus.isGranted && phoneStatus.isGranted;
  }
  
  // Gestionnaire d'événements pour les nouveaux SMS
  void _onNewSms(SmsMessage message) async {
    // Filtrer les SMS qui ne sont pas des messages de chat
    // Dans une implémentation réelle, vous pourriez avoir un préfixe spécial
    // ou une logique pour identifier les SMS liés à votre application
    
    // Pour l'instant, nous traitons tous les SMS comme des messages de chat
    await _smsService.receiveSms(
      message.address ?? 'Inconnu',
      message.body ?? 'Message vide',
    );
    
    print('SMS reçu de ${message.address}: ${message.body}');
  }
}
