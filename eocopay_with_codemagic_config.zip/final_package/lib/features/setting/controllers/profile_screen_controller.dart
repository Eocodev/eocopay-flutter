import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/auth/controllers/auth_controller.dart';
import 'package:six_cash/features/splash/controllers/splash_controller.dart';
import 'package:six_cash/features/setting/controllers/theme_controller.dart';
import 'package:six_cash/data/api/api_checker.dart';
import 'package:six_cash/features/auth/domain/models/user_short_data_model.dart';
import 'package:six_cash/features/setting/domain/models/profile_model.dart';
import 'package:six_cash/features/setting/domain/reposotories/profile_repo.dart';
import 'package:six_cash/helper/dialog_helper.dart';
import 'package:six_cash/helper/route_helper.dart';
import 'package:six_cash/common/widgets/custom_country_code_widget.dart';
import 'package:six_cash/helper/custom_snackbar_helper.dart';
import 'package:six_cash/common/widgets/custom_dialog_widget.dart';
import 'package:six_cash/util/app_constants.dart';
import 'package:six_cash/services/connectivity_service.dart';
import 'package:six_cash/services/local_storage_service.dart';

import '../../transaction_money/controllers/bootom_slider_controller.dart';

class ProfileController extends GetxController implements GetxService {
  final ProfileRepo profileRepo;
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  final LocalStorageService _localStorageService = Get.find<LocalStorageService>();
  
  ProfileController({required this.profileRepo});
  final BottomSliderController bottomSliderController =
      Get.find<BottomSliderController>();
  ProfileModel? _userInfo;
  bool _isLoading = false;
  final RxBool _isOfflineMode = false.obs;

  ProfileModel? get userInfo => _userInfo;
  bool get isLoading => _isLoading;
  bool get isOfflineMode => _isOfflineMode.value;
  String _gender = 'Male';
  String get gender => _gender;
  int select = 0;

  bool _showBalanceButtonTapped = false;
  bool get showBalanceButtonTapped => _showBalanceButtonTapped;

  set setUserInfo(ProfileModel value) {
    _userInfo = value;
  }

  @override
  void onInit() {
    super.onInit();
    // S'abonner aux changements de connectivité
    _connectivityService.connectivityStream.listen((isConnected) {
      _isOfflineMode.value = !isConnected;
      if (isConnected && _userInfo == null) {
        // Si la connexion est rétablie et que les données utilisateur ne sont pas chargées, les récupérer
        getProfileData(reload: true);
      }
    });
  }

  Future<void> getProfileData({bool reload = false, bool isUpdate = false}) async {
    if(reload || _userInfo == null) {
      _userInfo = null;
      _isLoading = true;
      if(isUpdate) {
        update();
      }
    }

    if(_userInfo == null) {
      // Vérifier si nous sommes en mode hors ligne
      bool isConnected = await _connectivityService.checkConnectivity();
      
      if (!isConnected) {
        // En mode hors ligne, essayer de récupérer les données du stockage local
        Map<String, dynamic>? cachedProfile = await _localStorageService.getUserProfile();
        
        if (cachedProfile != null) {
          _userInfo = ProfileModel.fromJson(cachedProfile);
          _isLoading = false;
          update();
          
          // Afficher une notification indiquant que les données sont en mode hors ligne
          showCustomSnackBarHelper(
            'Vous êtes en mode hors ligne. Les données affichées peuvent ne pas être à jour.',
            isError: false,
          );
          return;
        } else {
          // Aucune donnée en cache, afficher un message d'erreur
          showCustomSnackBarHelper(
            'Impossible de récupérer les données du profil en mode hors ligne.',
            isError: true,
          );
          _isLoading = false;
          update();
          return;
        }
      }
      
      // En mode en ligne, récupérer les données depuis l'API
      Response response = await profileRepo.getProfileDataApi();
      if (response.statusCode == 200) {
        _userInfo = ProfileModel.fromJson(response.body);

        // Mettre en cache les données du profil pour une utilisation hors ligne
        await _localStorageService.saveUserProfile(response.body);

        Get.find<AuthController>().setUserData(UserShortDataModel(
          name: '${_userInfo!.fName} ${_userInfo!.lName}',
          phone: userInfo?.phone?.replaceAll('${CustomCountryCodeWidget.getCountryCode(userInfo?.phone)}', ''),
          countryCode: CustomCountryCodeWidget.getCountryCode(userInfo?.phone),
          qrCode: _userInfo?.qrCode,
        ));

      } else {
        ApiChecker.checkApi(response);
      }
      _isLoading = false;
      update();
    }
  }

  // Afficher un indicateur de mode hors ligne
  Widget getOfflineModeIndicator() {
    return Obx(() => _isOfflineMode.value 
      ? Container(
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
          color: Colors.orange,
          width: double.infinity,
          child: const Text(
            'Mode hors ligne - Certaines fonctionnalités peuvent être limitées',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        )
      : const SizedBox.shrink()
    );
  }

  Future<void> changePin({required String oldPassword, required String newPassword, required String confirmPassword}) async {
    if ((oldPassword.length < 4) ||
        (newPassword.length < 4) ||
        (confirmPassword.length < 4)) {
      showCustomSnackBarHelper('please_input_4_digit_pin'.tr);
    } else if (newPassword != confirmPassword) {
      showCustomSnackBarHelper('pin_not_matched'.tr);
    } else {
      // Vérifier si nous sommes en mode hors ligne
      bool isConnected = await _connectivityService.checkConnectivity();
      
      if (!isConnected) {
        showCustomSnackBarHelper(
          'Cette fonctionnalité n\'est pas disponible en mode hors ligne.',
          isError: true,
        );
        return;
      }
      
      _isLoading = true;
      update();
      Response response = await profileRepo.changePinApi(
        oldPin: oldPassword, newPin: newPassword, confirmPin: confirmPassword,
      );

      if (response.statusCode == 200) {
        await Get.find<AuthController>().updatePin(newPassword);
        UserShortDataModel? userData = Get.find<AuthController>().getUserData();

        Get.offAllNamed(RouteHelper.getLoginRoute(
          countryCode: userData?.countryCode, phoneNumber: userData?.phone,
          userName: userData?.name ?? '',
        ));

      } else {
        ApiChecker.checkApi(response);
      }
      _isLoading = false;
      update();
    }
  }

  Future<Response> pinVerify({required String? getPin, bool isUpdateTwoFactor = true}) async {
    // Vérifier si nous sommes en mode hors ligne
    bool isConnected = await _connectivityService.checkConnectivity();
    
    if (!isConnected) {
      showCustomSnackBarHelper(
        'Cette fonctionnalité n\'est pas disponible en mode hors ligne.',
        isError: true,
      );
      return Response(statusCode: 0, statusText: 'Offline mode');
    }
    
    bottomSliderController.setIsLoading = true;
    final Response response = await profileRepo.pinVerifyApi(pin: getPin);

    if (response.statusCode == 200) {
      bottomSliderController.isPinVerified = true;
      bottomSliderController.setIsLoading = false;
      if(isUpdateTwoFactor) {
        updateTwoFactor();
      }
      bottomSliderController.resetPinField();
    } else {
      bottomSliderController.isPinVerified = false;
      bottomSliderController.setIsLoading = false;
      bottomSliderController.resetPinField();
      Get.back();
      showCustomSnackBarHelper('message');
      ApiChecker.checkApi(response);
    }
    update();
    return response;
  }

  Future<void> updateTwoFactor() async {
    // Vérifier si nous sommes en mode hors ligne
    bool isConnected = await _connectivityService.checkConnectivity();
    
    if (!isConnected) {
      showCustomSnackBarHelper(
        'Cette fonctionnalité n\'est pas disponible en mode hors ligne.',
        isError: true,
      );
      return;
    }
    
    _isLoading = true;
    update();
    Response response = await profileRepo.updateTwoFactorApi();
    await getProfileData(reload: true);
    if (response.statusCode == 200) {
      showCustomSnackBarHelper(response.body['message'], isError: false);
      _isLoading = false;
    } else {
      ApiChecker.checkApi(response);
      _isLoading = false;
    }
    update();
  }

  void routeToTwoFactorAuthScreen(String getPin) {
    pinVerify(getPin: getPin);
  }

  Future twoFactorOnTap() async {
    await pinVerify(getPin: bottomSliderController.pin);
  }

  void twoFactorOnChange() async {
    await updateTwoFactor();
    await getProfileData(reload: true);
  }

  ///Change theme..
  bool _isSwitched = Get.find<ThemeController>().darkTheme;
  var textValue = 'Switch is OFF';

  bool get isSwitched => _isSwitched;

  void onChangeTheme() {
    if (_isSwitched == false) {
      _isSwitched = true;
      textValue = 'Switch Button is ON';
      Get.find<ThemeController>().toggleTheme();
      update();

    } else {
      _isSwitched = false;
      textValue = 'Switch Button is OFF';
      Get.find<ThemeController>().toggleTheme();
      update();
    }
  }

  void logOut(BuildContext context) {
    DialogHelper.showAnimatedDialog(context,
        CustomDialogWidget(
          icon: Icons.logout,
          title: 'logout'.tr,
          description: 'are_you_sure_you_want_to_logout'.tr,
          onTapFalseText: 'clear_logout'.tr,
          onTapTrueText: 'logout'.tr,
          isFailed: true,
          onTapFalse: (){
            Get.find<AuthController>().removeBiometricPin().then((value) async{
              Get.find<SplashController>().removeSharedData();
              Get.find<AuthController>().updateToken(isLogOut: true);
              Get.find<AuthController>().logout();
              
              // Effacer également les données en cache
              await _localStorageService.clearCache();

              if(context.mounted) {
                Navigator.pop(context);
              }

            });

          },
          onTapTrue: (){
            Get.find<AuthController>().updateToken(isLogOut: true);
            Get.find<AuthController>().logout();
            
            // Effacer également les données en cache
            _localStorageService.clearCache();
            
            Navigator.of(context).pop(true);
          },
        ),
        dismissible: false,
        isFlip: true);
  }

  setGender(String select){
    _gender = select;
    update();
  }

  updateBalanceButtonTappedStatus({bool shouldUpdate = true}){
    _showBalanceButtonTapped = true;

    if(shouldUpdate){
      update();
    } else{
      _showBalanceButtonTapped = false;
    }

    Future.delayed(const Duration(seconds: AppConstants.balanceHideDurationInSecond),(){
      _showBalanceButtonTapped = false;
      update();
    });
  }

  Future<void> toggleUserBalanceShowingStatus() async {
    bool value  = profileRepo.isUserBalanceHide();
    profileRepo.toggleUserBalanceShowingStatus(!value);
  }

  bool isUserBalanceHide() {
    return profileRepo.isUserBalanceHide();
  }
}
