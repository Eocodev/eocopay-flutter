import 'package:six_cash/data/api/api_checker.dart';
import 'package:six_cash/features/add_money/domain/reposotories/add_money_repo.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/add_money/screens/web_screen.dart';
import 'package:six_cash/features/payment/domain/models/payment_models.dart';
import 'package:six_cash/features/payment/domain/services/payment_manager.dart';

class AddMoneyController extends GetxController implements GetxService {
  final AddMoneyRepo addMoneyRepo;
  AddMoneyController({required this.addMoneyRepo});

  bool _isLoading = false;
  String? _addMoneyWebLink;
  bool get isLoading => _isLoading;
  String? get addMoneyWebLink => _addMoneyWebLink;

  String? _paymentMethod;
  String? get paymentMethod => _paymentMethod;

  // Résultat du dernier paiement
  PaymentResult? _lastPaymentResult;
  PaymentResult? get lastPaymentResult => _lastPaymentResult;

  Future<void> addMoney(double amount) async {
    _isLoading = true;
    update();

    try {
      // Vérifier si la méthode de paiement est CinetPay
      if (_paymentMethod == 'cinetpay' || _paymentMethod?.startsWith('cinetpay_') == true) {
        await _processCinetPayPayment(amount);
      } 
      // Vérifier si la méthode de paiement est SMobilPay
      else if (_paymentMethod == 'smobilpay' || _paymentMethod?.startsWith('smobilpay_') == true) {
        await _processSMobilPayPayment(amount);
      }
      // Méthode de paiement existante
      else {
        await _processExistingPayment(amount);
      }
    } catch (e) {
      _lastPaymentResult = PaymentResult.error("Erreur lors du traitement du paiement: ${e.toString()}");
    }

    _isLoading = false;
    update();
  }

  // Traitement du paiement via CinetPay
  Future<void> _processCinetPayPayment(double amount) async {
    try {
      final PaymentManager paymentManager = Get.find<PaymentManager>();
      
      final result = await paymentManager.processPayment(
        paymentMethodId: _paymentMethod!,
        amount: amount,
        currency: 'XOF', // À adapter selon les besoins
        description: "Ajout d'argent via CinetPay",
      );
      
      _lastPaymentResult = result;
      
      if (result.isSuccess) {
        // Notifier le serveur du paiement réussi
        await addMoneyRepo.addMoneyApi(
          amount: amount, 
          paymentMethod: _paymentMethod!,
          transactionReference: result.data?['operator_id'] ?? '',
        );
      }
    } catch (e) {
      _lastPaymentResult = PaymentResult.error("Erreur lors du traitement du paiement CinetPay: ${e.toString()}");
    }
  }

  // Traitement du paiement via SMobilPay
  Future<void> _processSMobilPayPayment(double amount) async {
    try {
      final PaymentManager paymentManager = Get.find<PaymentManager>();
      
      final result = await paymentManager.processPayment(
        paymentMethodId: _paymentMethod!,
        amount: amount,
        currency: 'XAF', // Devise pour SMobilPay (à adapter selon les besoins)
        description: "Ajout d'argent via SMobilPay",
      );
      
      _lastPaymentResult = result;
      
      if (result.isSuccess) {
        // Notifier le serveur du paiement réussi
        await addMoneyRepo.addMoneyApi(
          amount: amount, 
          paymentMethod: _paymentMethod!,
          transactionReference: result.data?['payment_id'] ?? '',
        );
      }
    } catch (e) {
      _lastPaymentResult = PaymentResult.error("Erreur lors du traitement du paiement SMobilPay: ${e.toString()}");
    }
  }

  // Traitement du paiement via les méthodes existantes
  Future<void> _processExistingPayment(double amount) async {
    Response response = await addMoneyRepo.addMoneyApi(
      amount: amount, 
      paymentMethod: _paymentMethod!
    );
    
    if (response.statusCode == 200) {
      _addMoneyWebLink = response.body['link'];
      if (_addMoneyWebLink != null) {
        Get.offAll(() => WebScreen(selectedUrl: _addMoneyWebLink!, isPaymentUrl: true));
      }
    } else {
      ApiChecker.checkApi(response);
      _lastPaymentResult = PaymentResult.error("Échec de la requête de paiement");
    }
  }

  void setPaymentMethod(String? method, {isUpdate = true}) {
    _paymentMethod = method;
    if (isUpdate) {
      update();
    }
  }

  void clearPaymentResult() {
    _lastPaymentResult = null;
    update();
  }
}
