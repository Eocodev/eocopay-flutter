import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/features/add_money/controllers/add_money_controller.dart';
import 'package:six_cash/features/payment/widgets/payment_selection_button.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/util/styles.dart';
import 'package:six_cash/common/widgets/custom_app_bar.dart';
import 'package:six_cash/common/widgets/custom_snackbar.dart';
import 'package:six_cash/common/widgets/custom_text_field.dart';

class AddMoneyScreen extends StatefulWidget {
  const AddMoneyScreen({Key? key}) : super(key: key);

  @override
  State<AddMoneyScreen> createState() => _AddMoneyScreenState();
}

class _AddMoneyScreenState extends State<AddMoneyScreen> {
  final TextEditingController _amountController = TextEditingController();
  final FocusNode _amountFocus = FocusNode();
  double _amount = 0.0;

  @override
  void dispose() {
    _amountController.dispose();
    _amountFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Ajouter de l\'argent'),
      body: GetBuilder<AddMoneyController>(
        builder: (addMoneyController) {
          return Padding(
            padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Montant
                Text(
                  'Montant',
                  style: rubikMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                CustomTextField(
                  hintText: 'Entrez le montant',
                  controller: _amountController,
                  focusNode: _amountFocus,
                  inputType: TextInputType.number,
                  onChanged: (value) {
                    try {
                      _amount = double.parse(value);
                    } catch (e) {
                      _amount = 0.0;
                    }
                  },
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                // Bouton de sélection de paiement
                PaymentSelectionButton(
                  amount: _amount,
                  onPaymentComplete: (success) {
                    if (success) {
                      showCustomSnackBar('Argent ajouté avec succès', isError: false);
                      _amountController.clear();
                      _amount = 0.0;
                    }
                  },
                ),

                const SizedBox(height: Dimensions.paddingSizeLarge),

                // Résultat du paiement
                if (addMoneyController.lastPaymentResult != null)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                    decoration: BoxDecoration(
                      color: addMoneyController.lastPaymentResult!.isSuccess
                          ? Colors.green.withOpacity(0.1)
                          : Colors.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(Dimensions.radiusSizeSmall),
                    ),
                    child: Text(
                      addMoneyController.lastPaymentResult!.message,
                      style: rubikRegular.copyWith(
                        color: addMoneyController.lastPaymentResult!.isSuccess
                            ? Colors.green
                            : Colors.red,
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
