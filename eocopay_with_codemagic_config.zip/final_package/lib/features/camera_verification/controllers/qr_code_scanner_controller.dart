import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:six_cash/common/models/contact_model.dart';
import 'package:six_cash/services/connectivity_service.dart';
import 'package:six_cash/services/local_storage_service.dart';
import 'package:six_cash/util/dimensions.dart';
import 'package:six_cash/features/transaction_money/screens/transaction_balance_input_screen.dart';

class QrCodeScannerController extends GetxController implements GetxService {
  final ConnectivityService _connectivityService = Get.find<ConnectivityService>();
  final LocalStorageService _localStorageService = Get.find<LocalStorageService>();
  
  bool _isBusy = false;
  bool _isDetect = false;
  final RxBool _isOfflineMode = false.obs;

  String? _name;
  String? _phone;
  String? _type;
  String? _image;

  String? get name => _name;
  String? get phone => _phone;
  String? get type => _type;
  String? get image => _image;
  String? _transactionType;
  String? get transactionType => _transactionType;
  bool get isOfflineMode => _isOfflineMode.value;

  @override
  void onInit() {
    super.onInit();
    // S'abonner aux changements de connectivité
    _connectivityService.connectivityStream.listen((isConnected) {
      _isOfflineMode.value = !isConnected;
    });
  }

  Future<void> processImage(InputImage inputImage, bool isHome, String? transactionType) async {
    final BarcodeScanner barcodeScanner = BarcodeScanner();
    if (_isBusy) return;
    _isBusy = true;

    try {
      final barcodes = await barcodeScanner.processImage(inputImage);
      if (inputImage.metadata?.size != null && inputImage.metadata?.rotation != null) {
        for (final barcode in barcodes) {
          try {
            // Extraire les données du QR code
            _name = jsonDecode(barcode.rawValue!)['name'];
            _phone = jsonDecode(barcode.rawValue!)['phone'];
            _type = jsonDecode(barcode.rawValue!)['type'];
            _image = jsonDecode(barcode.rawValue!)['image'];
            
            if (_name != null && _phone != null && _type != null && _image != null) {
              // Créer un modèle de contact à partir des données du QR code
              ContactModel contactModel = ContactModel(
                phoneNumber: _phone,
                name: _name,
                avatarImage: _image,
                type: _type
              );
              
              // Sauvegarder le contact scanné dans le stockage local
              await _localStorageService.saveRecentQrCode(contactModel);
              
              // Déterminer le type de transaction
              if (_type == "customer") {
                _transactionType = transactionType;
              } else if (_type == "agent") {
                _transactionType = "cash_out";
              }
              
              // Navigation selon le contexte
              if (isHome && _type != "agent") {
                if (!_isDetect) {
                  Get.defaultDialog(
                    title: 'select_a_transaction'.tr,
                    content: TransactionSelect(contactModel: contactModel),
                    barrierDismissible: false,
                    radius: Dimensions.radiusSizeDefault,
                  ).then((value) {
                    _isDetect = false;
                  });
                }
                _isDetect = true;
              } else {
                Get.to(() => TransactionBalanceInputScreen(
                  transactionType: _transactionType,
                  contactModel: contactModel
                ));
              }
            }
          } catch (e) {
            print('Erreur lors du traitement du QR code: $e');
            // Afficher un message d'erreur à l'utilisateur
            Get.snackbar(
              'Erreur',
              'Format de QR code non valide ou incomplet',
              backgroundColor: Colors.red,
              colorText: Colors.white,
              snackPosition: SnackPosition.BOTTOM
            );
          }
        }
      }
    } catch (e) {
      print('Erreur lors du scan QR: $e');
      // Afficher un message d'erreur à l'utilisateur
      Get.snackbar(
        'Erreur',
        'Impossible de scanner le QR code',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM
      );
    } finally {
      _isBusy = false;
    }
  }

  // Récupérer les contacts récemment scannés
  Future<List<ContactModel>> getRecentQrContacts() async {
    return await _localStorageService.getRecentQrCodes();
  }
}

class TransactionSelect extends StatelessWidget {
  final ContactModel? contactModel;
  const TransactionSelect({super.key, this.contactModel});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ListTile(
          title: Text('send_money'.tr),
          minVerticalPadding: 0,
          onTap: () => Get.off(() => TransactionBalanceInputScreen(
            transactionType: 'send_money',
            contactModel: contactModel
          ))
        ),
        ListTile(
          title: Text('request_money'.tr),
          minVerticalPadding: 0,
          onTap: () => Get.off(() => TransactionBalanceInputScreen(
            transactionType: 'request_money',
            contactModel: contactModel
          ))
        ),
      ],
    );
  }
}
