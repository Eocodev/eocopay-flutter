import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/services/connectivity_service.dart';

class OfflineModeWidget extends StatelessWidget {
  final Widget child;
  final bool showIndicator;
  
  const OfflineModeWidget({
    Key? key, 
    required this.child,
    this.showIndicator = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ConnectivityService connectivityService = Get.find<ConnectivityService>();
    
    return Obx(() {
      final bool isOffline = !connectivityService.isConnected;
      
      return Column(
        children: [
          if (isOffline && showIndicator)
            Container(
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
              color: Colors.orange,
              width: double.infinity,
              child: const Text(
                'Mode hors ligne - Certaines fonctionnalités peuvent être limitées',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
          Expanded(child: child),
        ],
      );
    });
  }
}
