import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/services/connectivity_service.dart';
import 'package:six_cash/services/local_storage_service.dart';
import 'package:six_cash/common/models/contact_model.dart';

class RecentQrContactsWidget extends StatelessWidget {
  final Function(ContactModel) onContactSelected;
  
  const RecentQrContactsWidget({
    Key? key,
    required this.onContactSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final LocalStorageService localStorageService = Get.find<LocalStorageService>();
    
    return FutureBuilder<List<ContactModel>>(
      future: localStorageService.getRecentQrCodes(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.qr_code, size: 48, color: Colors.grey),
                const SizedBox(height: 16),
                Text(
                  'Aucun contact QR récent',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.grey),
                ),
              ],
            ),
          );
        }
        
        return ListView.builder(
          itemCount: snapshot.data!.length,
          itemBuilder: (context, index) {
            final contact = snapshot.data![index];
            return ListTile(
              leading: CircleAvatar(
                backgroundImage: contact.avatarImage != null && contact.avatarImage!.isNotEmpty
                    ? NetworkImage(contact.avatarImage!)
                    : null,
                child: contact.avatarImage == null || contact.avatarImage!.isEmpty
                    ? Text(contact.name?.substring(0, 1) ?? 'U')
                    : null,
              ),
              title: Text(contact.name ?? 'Inconnu'),
              subtitle: Text(contact.phoneNumber ?? ''),
              trailing: const Icon(Icons.qr_code),
              onTap: () => onContactSelected(contact),
            );
          },
        );
      },
    );
  }
}
