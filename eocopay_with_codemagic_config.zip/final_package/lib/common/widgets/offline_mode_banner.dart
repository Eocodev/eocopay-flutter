import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/services/connectivity_service.dart';
import 'package:six_cash/services/local_storage_service.dart';

class OfflineModeBanner extends StatelessWidget {
  const OfflineModeBanner({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ConnectivityService connectivityService = Get.find<ConnectivityService>();
    
    return Obx(() {
      final bool isOffline = !connectivityService.isConnected;
      
      return isOffline 
        ? Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
            color: Colors.orange,
            width: double.infinity,
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.wifi_off, color: Colors.white, size: 16),
                SizedBox(width: 8),
                Flexible(
                  child: Text(
                    'Mode hors ligne - Certaines fonctionnalités peuvent être limitées',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          )
        : const SizedBox.shrink();
    });
  }
}
