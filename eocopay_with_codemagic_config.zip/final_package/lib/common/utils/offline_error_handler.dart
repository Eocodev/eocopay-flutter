import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/services/connectivity_service.dart';
import 'package:six_cash/services/local_storage_service.dart';

class OfflineErrorHandler {
  static void handleError(BuildContext context, String message, {bool isError = true}) {
    final ConnectivityService connectivityService = Get.find<ConnectivityService>();
    
    if (!connectivityService.isConnected) {
      // En mode hors ligne, afficher un message spécifique
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.wifi_off, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Mode hors ligne: $message',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          backgroundColor: isError ? Colors.red : Colors.orange,
          duration: const Duration(seconds: 3),
        ),
      );
    } else {
      // En mode en ligne, afficher un message standard
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: isError ? Colors.red : Colors.green,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }
  
  static Widget buildOfflineErrorWidget(String message, {IconData icon = Icons.wifi_off}) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 64, color: Colors.grey),
          const SizedBox(height: 16),
          Text(
            message,
            style: const TextStyle(fontSize: 16, color: Colors.grey),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
