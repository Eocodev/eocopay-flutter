import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_cash/services/dependency_injection.dart';
import 'package:six_cash/common/widgets/offline_mode_banner.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialiser les services pour le mode hors ligne
  await DependencyInjection.init();
  
  // Continuer avec l'initialisation normale de l'application
  // ... code existant ...
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Six Cash',
      theme: ThemeData(
        // ... configuration du thème existante ...
      ),
      builder: (context, child) {
        return Column(
          children: [
            // Ajouter la bannière de mode hors ligne en haut de l'application
            const OfflineModeBanner(),
            
            // Contenu principal de l'application
            Expanded(child: child ?? const SizedBox.shrink()),
          ],
        );
      },
      // ... autres configurations existantes ...
    );
  }
}
