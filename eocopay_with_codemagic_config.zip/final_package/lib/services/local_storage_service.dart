import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:six_cash/common/models/contact_model.dart';

class LocalStorageService extends GetxService {
  final SharedPreferences sharedPreferences;
  final FlutterSecureStorage secureStorage = const FlutterSecureStorage();
  
  LocalStorageService({required this.sharedPreferences});
  
  // Clés pour le stockage
  static const String _recentQrCodesKey = 'recent_qr_codes';
  static const String _userProfileKey = 'user_profile_data';
  static const String _lastSyncTimeKey = 'last_sync_time';
  
  // Stocker un code QR scanné récemment
  Future<void> saveRecentQrCode(ContactModel contactModel) async {
    try {
      // Récupérer les codes QR existants
      List<ContactModel> recentQrCodes = await getRecentQrCodes();
      
      // Vérifier si ce contact existe déjà
      bool exists = recentQrCodes.any((element) => 
        element.phoneNumber == contactModel.phoneNumber);
      
      // Si le contact n'existe pas, l'ajouter à la liste
      if (!exists) {
        recentQrCodes.add(contactModel);
        
        // Limiter à 10 contacts récents
        if (recentQrCodes.length > 10) {
          recentQrCodes.removeAt(0);
        }
        
        // Convertir la liste en JSON et sauvegarder
        List<String> jsonList = recentQrCodes.map((contact) => 
          jsonEncode({
            'name': contact.name,
            'phoneNumber': contact.phoneNumber,
            'avatarImage': contact.avatarImage,
            'type': contact.type ?? 'customer'
          })
        ).toList();
        
        await sharedPreferences.setStringList(_recentQrCodesKey, jsonList);
      }
    } catch (e) {
      print('Erreur lors de la sauvegarde du code QR: $e');
    }
  }
  
  // Récupérer les codes QR récemment scannés
  Future<List<ContactModel>> getRecentQrCodes() async {
    try {
      List<String>? jsonList = sharedPreferences.getStringList(_recentQrCodesKey);
      
      if (jsonList == null || jsonList.isEmpty) {
        return [];
      }
      
      return jsonList.map((jsonString) {
        Map<String, dynamic> map = jsonDecode(jsonString);
        return ContactModel(
          name: map['name'],
          phoneNumber: map['phoneNumber'],
          avatarImage: map['avatarImage'],
          type: map['type']
        );
      }).toList();
    } catch (e) {
      print('Erreur lors de la récupération des codes QR: $e');
      return [];
    }
  }
  
  // Stocker les données du profil utilisateur
  Future<void> saveUserProfile(Map<String, dynamic> profileData) async {
    try {
      String jsonData = jsonEncode(profileData);
      await secureStorage.write(key: _userProfileKey, value: jsonData);
      
      // Enregistrer l'heure de la dernière synchronisation
      await sharedPreferences.setString(_lastSyncTimeKey, DateTime.now().toIso8601String());
    } catch (e) {
      print('Erreur lors de la sauvegarde du profil utilisateur: $e');
    }
  }
  
  // Récupérer les données du profil utilisateur
  Future<Map<String, dynamic>?> getUserProfile() async {
    try {
      String? jsonData = await secureStorage.read(key: _userProfileKey);
      
      if (jsonData == null || jsonData.isEmpty) {
        return null;
      }
      
      return jsonDecode(jsonData);
    } catch (e) {
      print('Erreur lors de la récupération du profil utilisateur: $e');
      return null;
    }
  }
  
  // Vérifier si une synchronisation est nécessaire
  Future<bool> isSyncRequired() async {
    String? lastSyncTimeStr = sharedPreferences.getString(_lastSyncTimeKey);
    
    if (lastSyncTimeStr == null) {
      return true;
    }
    
    DateTime lastSyncTime = DateTime.parse(lastSyncTimeStr);
    DateTime now = DateTime.now();
    
    // Synchroniser si la dernière synchronisation date de plus de 24 heures
    return now.difference(lastSyncTime).inHours > 24;
  }
  
  // Effacer toutes les données mises en cache
  Future<void> clearCache() async {
    await sharedPreferences.remove(_recentQrCodesKey);
    await sharedPreferences.remove(_lastSyncTimeKey);
    await secureStorage.delete(key: _userProfileKey);
  }
}
