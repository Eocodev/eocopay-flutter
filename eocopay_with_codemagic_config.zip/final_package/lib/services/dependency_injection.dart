import 'package:get/get.dart';
import 'package:six_cash/services/connectivity_service.dart';
import 'package:six_cash/services/local_storage_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class DependencyInjection {
  static Future<void> init() async {
    // Services tiers
    final sharedPreferences = await SharedPreferences.getInstance();
    
    // Enregistrer les services
    Get.lazyPut(() => ConnectivityService(), fenix: true);
    Get.lazyPut(() => LocalStorageService(sharedPreferences: sharedPreferences), fenix: true);
    
    // Initialiser les services si nécessaire
    await Get.find<ConnectivityService>().onInit();
  }
}
