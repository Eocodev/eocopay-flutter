# Documentation d'intégration des passerelles de paiement

## Introduction

Cette documentation détaille l'intégration des passerelles de paiement CinetPay et SMobilPay dans l'application Six Cash. Ces intégrations permettent aux utilisateurs d'effectuer des paiements via ces deux services, que ce soit en ligne ou hors ligne.

## Configuration des passerelles de paiement

### Prérequis

Pour utiliser les passerelles de paiement, vous devez disposer des éléments suivants :

#### Pour CinetPay :
- Une clé API CinetPay
- Un identifiant de site (Site ID)
- Une URL de notification

#### Pour SMobilPay :
- Un token d'accès public
- Une clé secrète d'accès
- Une URL de callback

### Configuration

1. Ouvrez le fichier `lib/features/payment/config/app_config.dart`
2. Remplacez les valeurs par défaut par vos propres informations d'identification :

```dart
// Configuration CinetPay
AppConstants.CINETPAY_API_KEY = 'VOTRE_CLE_API_CINETPAY';
AppConstants.CINETPAY_SITE_ID = 12345; // Votre Site ID
AppConstants.CINETPAY_NOTIFY_URL = 'https://votre-domaine.com/notify/cinetpay';

// Configuration SMobilPay
AppConstants.SMOBILPAY_PUBLIC_TOKEN = 'VOTRE_TOKEN_PUBLIC_SMOBILPAY';
AppConstants.SMOBILPAY_ACCESS_SECRET = 'VOTRE_SECRET_SMOBILPAY';
AppConstants.SMOBILPAY_ENVIRONMENT = 'test'; // 'test' ou 'production'
AppConstants.SMOBILPAY_CALLBACK_URL = 'https://votre-domaine.com/notify/smobilpay';
```

3. Assurez-vous que l'initialisation des passerelles de paiement est appelée dans votre fichier `main.dart` :

```dart
import 'package:six_cash/features/payment/config/app_config.dart';

void main() {
  // Initialisation des passerelles de paiement
  AppConfig.initializePaymentGateways();
  
  // Reste du code d'initialisation
  runApp(MyApp());
}
```

## Architecture des passerelles de paiement

L'intégration des passerelles de paiement suit une architecture modulaire basée sur des interfaces :

1. **Interface PaymentService** : Définit le contrat pour toutes les passerelles de paiement
2. **Adaptateurs spécifiques** : Implémentent l'interface pour chaque passerelle (CinetPayAdapter, SMobilPayAdapter)
3. **Gestionnaire de paiement** : Coordonne les différentes passerelles et fournit une interface unifiée

Cette architecture permet d'ajouter facilement de nouvelles passerelles de paiement à l'avenir.

## Utilisation des passerelles de paiement

### Interface unifiée de paiement

L'application propose une interface unifiée pour effectuer des paiements, accessible via le widget `PaymentSelectionButton` :

```dart
PaymentSelectionButton(
  amount: 1000.0, // Montant en FCFA
  onPaymentComplete: (success) {
    if (success) {
      // Traitement après paiement réussi
    }
  },
)
```

### Traitement direct des paiements

Pour un contrôle plus précis, vous pouvez utiliser directement le gestionnaire de paiement :

```dart
final PaymentManager paymentManager = Get.find<PaymentManager>();

final result = await paymentManager.processPayment(
  paymentMethodId: 'cinetpay', // ou 'smobilpay'
  amount: 1000.0,
  currency: 'XOF', // 'XOF' pour CinetPay, 'XAF' pour SMobilPay
  description: "Description du paiement",
);

if (result.isSuccess) {
  // Paiement réussi
  print('Transaction ID: ${result.data['transaction_id']}');
} else {
  // Échec du paiement
  print('Erreur: ${result.message}');
}
```

## Tests des passerelles de paiement

L'application inclut un module de test pour vérifier le bon fonctionnement des passerelles de paiement :

1. Accédez à l'écran de test via `PaymentTestMenuScreen`
2. Sélectionnez la passerelle à tester
3. Choisissez un montant de test
4. Vérifiez les résultats du test

## Fonctionnement hors ligne

Les passerelles de paiement sont intégrées avec le système de gestion hors ligne de l'application :

1. Les transactions initiées hors ligne sont mises en file d'attente
2. Lorsque la connexion est rétablie, les transactions sont automatiquement synchronisées
3. L'utilisateur est informé de l'état de ses transactions via des notifications

## Dépannage

### Problèmes courants avec CinetPay

- **Erreur d'authentification** : Vérifiez que votre clé API et votre Site ID sont corrects
- **Échec de transaction** : Assurez-vous que le compte de test dispose de fonds suffisants
- **Problèmes de callback** : Vérifiez que votre URL de notification est accessible publiquement

### Problèmes courants avec SMobilPay

- **Erreur de signature** : Vérifiez que votre clé secrète est correcte
- **Erreur 401** : Assurez-vous que votre token d'accès public est valide
- **Échec de transaction** : Vérifiez que vous utilisez la bonne devise (XAF)

## Ressources supplémentaires

- [Documentation officielle CinetPay](https://docs.cinetpay.com/)
- [Documentation API SMobilPay](https://apidocs.smobilpay.com/)
