// Logos des passerelles de paiement pour l'interface utilisateur
// Ces fichiers SVG sont des placeholders et devraient être remplacés par les logos officiels
// des passerelles de paiement dans un environnement de production.

// Logo CinetPay
<svg xmlns="http://www.w3.org/2000/svg" width="200" height="80" viewBox="0 0 200 80">
  <rect width="200" height="80" fill="#003E47" rx="10" ry="10"/>
  <text x="100" y="50" font-family="Arial" font-size="24" fill="#FFFFFF" text-anchor="middle">CinetPay</text>
</svg>

// Logo SMobilPay
<svg xmlns="http://www.w3.org/2000/svg" width="200" height="80" viewBox="0 0 200 80">
  <rect width="200" height="80" fill="#E0EC53" rx="10" ry="10"/>
  <text x="100" y="50" font-family="Arial" font-size="24" fill="#003E47" text-anchor="middle">SMobilPay</text>
</svg>
